import { ReactNode } from "react";

/* ---------------- Section ---------------- */
export function Section({
  title,
  id,
  children,
}: {
  title: string;
  id?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className="mb-10 scroll-mt-24 sm:mb-12">
      <h2 className="mb-4 flex items-start gap-2.5 text-xl font-bold text-white sm:items-center sm:gap-3 sm:text-2xl">
        <span className="mt-1 inline-block h-5 w-1.5 shrink-0 rounded-full bg-gradient-to-b from-emerald-400 to-cyan-500 sm:mt-0 sm:h-6"></span>
        <span className="min-w-0 break-words">{title}</span>
      </h2>
      <div className="min-w-0">{children}</div>
    </section>
  );
}

export function SubSection({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="mb-6 min-w-0">
      <h3 className="mb-2 text-base font-semibold text-emerald-300 sm:text-lg">
        {title}
      </h3>
      <div className="min-w-0 text-slate-300">{children}</div>
    </div>
  );
}

/* ---------------- Note Box ---------------- */
const boxStyles = {
  info: {
    cls: "border-sky-500/40 bg-sky-500/10",
    icon: "💡",
    label: "Note",
    ic: "text-sky-300",
  },
  tip: {
    cls: "border-emerald-500/40 bg-emerald-500/10",
    icon: "✨",
    label: "Tip",
    ic: "text-emerald-300",
  },
  warn: {
    cls: "border-amber-500/40 bg-amber-500/10",
    icon: "⚠️",
    label: "Warning",
    ic: "text-amber-300",
  },
  exam: {
    cls: "border-violet-500/40 bg-violet-500/10",
    icon: "🎓",
    label: "Exam Tip",
    ic: "text-violet-300",
  },
} as const;

export function NoteBox({
  type = "info",
  title,
  children,
}: {
  type?: keyof typeof boxStyles;
  title?: string;
  children: ReactNode;
}) {
  const s = boxStyles[type];
  return (
    <div
      className={`my-4 rounded-xl border ${s.cls} p-3.5 backdrop-blur-sm sm:p-4`}
    >
      <div
        className={`mb-1.5 flex items-center gap-2 text-sm font-semibold ${s.ic}`}
      >
        <span className="text-base leading-none">{s.icon}</span>
        <span>{title || s.label}</span>
      </div>
      <div className="text-[13.5px] leading-relaxed text-slate-300 sm:text-sm">
        {children}
      </div>
    </div>
  );
}

/* ---------------- Inline Code ---------------- */
export function IC({ children }: { children: ReactNode }) {
  return (
    <code className="break-words rounded bg-slate-800/90 px-1.5 py-0.5 font-mono text-[0.85em] text-emerald-300">
      {children}
    </code>
  );
}

/** alias kept for readability */
export const InlineCode = IC;

/* ---------------- Responsive Table ---------------- */
export function Table({
  headers,
  rows,
  caption,
}: {
  headers: string[];
  rows: (string | ReactNode)[][];
  caption?: string;
}) {
  return (
    <div className="my-4 w-full min-w-0">
      <div className="-mx-3 overflow-x-auto px-3 sm:mx-0 sm:px-0">
        <div className="min-w-full rounded-xl border border-slate-700/80">
          <table className="w-full min-w-[420px] border-collapse text-left text-[13px] sm:text-sm">
            <thead className="bg-slate-800/80 text-slate-200">
              <tr>
                {headers.map((h, i) => (
                  <th
                    key={i}
                    className="whitespace-nowrap px-3 py-2.5 font-semibold sm:px-4"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr
                  key={i}
                  className="border-t border-slate-800 bg-slate-900/40 text-slate-300 even:bg-slate-900/70"
                >
                  {row.map((cell, j) => (
                    <td
                      key={j}
                      className="px-3 py-2.5 align-top sm:px-4 [&_code]:break-words"
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {caption && (
        <p className="mt-1.5 text-center text-[11px] italic text-slate-500">
          {caption}
          {/* swipe horizontally on small screens */}
        </p>
      )}
    </div>
  );
}

/* ---------------- Card Grid ---------------- */
export function CardGrid({
  items,
  cols = 2,
}: {
  items: { t: string; d: ReactNode; icon?: string }[];
  cols?: 2 | 3;
}) {
  return (
    <div
      className={`my-4 grid gap-3 ${
        cols === 3
          ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
          : "grid-cols-1 sm:grid-cols-2"
      }`}
    >
      {items.map((it) => (
        <div
          key={it.t}
          className="min-w-0 rounded-xl border border-slate-700/70 bg-slate-800/40 p-3.5 transition hover:border-slate-600"
        >
          <div className="mb-1 flex items-center gap-2 font-semibold text-emerald-300">
            {it.icon && <span>{it.icon}</span>}
            <span className="break-words">{it.t}</span>
          </div>
          <div className="text-[13px] leading-relaxed text-slate-400 sm:text-sm">
            {it.d}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Definition list ---------------- */
export function DefList({
  items,
}: {
  items: { term: string; def: ReactNode }[];
}) {
  return (
    <dl className="my-4 divide-y divide-slate-800 overflow-hidden rounded-xl border border-slate-700/70">
      {items.map((it) => (
        <div
          key={it.term}
          className="grid gap-1 bg-slate-900/40 p-3.5 sm:grid-cols-[minmax(120px,180px)_1fr] sm:gap-4"
        >
          <dt className="break-words font-semibold text-emerald-300">
            {it.term}
          </dt>
          <dd className="text-[13.5px] leading-relaxed text-slate-300 sm:text-sm">
            {it.def}
          </dd>
        </div>
      ))}
    </dl>
  );
}

/* ---------------- Timeline ---------------- */
export function Timeline({
  items,
}: {
  items: { year: string; title: string; body: ReactNode; hot?: boolean }[];
}) {
  return (
    <div className="my-5 min-w-0 space-y-0">
      {items.map((it, i) => (
        <div key={it.year + i} className="relative flex gap-3 sm:gap-4">
          {/* rail */}
          {i < items.length - 1 && (
            <span className="absolute left-[15px] top-8 h-[calc(100%-8px)] w-0.5 bg-slate-700/70 sm:left-[19px]" />
          )}
          <div
            className={`relative z-10 mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-[10px] font-bold sm:h-10 sm:w-10 sm:text-xs ${
              it.hot
                ? "border-emerald-400 bg-emerald-500/20 text-emerald-300 shadow-lg shadow-emerald-500/20"
                : "border-slate-600 bg-slate-800 text-slate-400"
            }`}
          >
            {it.hot ? "★" : i + 1}
          </div>
          <div className="min-w-0 flex-1 pb-6">
            <div className="mb-1 flex flex-wrap items-baseline gap-x-2 gap-y-1">
              <span
                className={`font-mono text-sm font-bold ${
                  it.hot ? "text-emerald-300" : "text-slate-400"
                }`}
              >
                {it.year}
              </span>
              <span className="break-words font-semibold text-white">
                {it.title}
              </span>
            </div>
            <div className="text-[13.5px] leading-relaxed text-slate-400 sm:text-sm">
              {it.body}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Collapsible ---------------- */
export function Collapse({
  question,
  children,
}: {
  question: string;
  children: ReactNode;
}) {
  return (
    <details className="group my-2 overflow-hidden rounded-xl border border-slate-700 bg-slate-900/50">
      <summary
        className="flex cursor-pointer list-none items-start justify-between gap-3 p-3.5 text-[13.5px] font-semibold text-white transition hover:bg-slate-800/50 sm:text-sm"
      >
        <span className="min-w-0 break-words">{question}</span>
        <span className="mt-0.5 shrink-0 text-emerald-400 transition group-open:rotate-45">
          ＋
        </span>
      </summary>
      <div className="border-t border-slate-800 bg-slate-950/40 p-3.5 text-[13.5px] leading-relaxed text-slate-300 sm:text-sm">
        {children}
      </div>
    </details>
  );
}
