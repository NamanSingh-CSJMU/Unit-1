import { useMemo, useState } from "react";

const BS = String.fromCharCode(92); // one backslash character

/**
 * Some source strings arrive with a real line break where C expects an
 * escape sequence. A real newline can never legally appear inside a C string
 * literal, so any newline found inside quotes is converted back to \n.
 */
function repairEscapes(code: string): string {
  let out = "";
  let quote: string | null = null;
  let lineComment = false;
  let blockComment = false;

  for (let i = 0; i < code.length; i++) {
    const ch = code[i];
    const next = code[i + 1];

    if (lineComment) {
      out += ch;
      if (ch === "\n") lineComment = false;
      continue;
    }
    if (blockComment) {
      out += ch;
      if (ch === "*" && next === "/") {
        out += next;
        i++;
        blockComment = false;
      }
      continue;
    }
    if (quote) {
      if (ch === "\n") {
        out += BS + "n";
        continue;
      }
      out += ch;
      if (ch === BS) {
        out += next ?? "";
        i++;
        continue;
      }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === "/" && next === "/") {
      lineComment = true;
      out += "//";
      i++;
      continue;
    }
    if (ch === "/" && next === "*") {
      blockComment = true;
      out += "/*";
      i++;
      continue;
    }
    if (ch === '"' || ch === "'") quote = ch;
    out += ch;
  }
  return out;
}

// Lightweight C syntax highlighter (no external deps)
function highlight(code: string): string {
  const keywords = [
    "auto", "break", "case", "char", "const", "continue", "default", "do",
    "double", "else", "enum", "extern", "float", "for", "goto", "if",
    "int", "long", "register", "return", "short", "signed", "sizeof",
    "static", "struct", "switch", "typedef", "union", "unsigned", "void",
    "volatile", "while", "include", "define", "main",
  ];

  let escaped = code
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  escaped = escaped.replace(
    /("(?:[^"\\]|\\.)*")/g,
    '<span class="text-amber-300">$1</span>'
  );
  escaped = escaped.replace(
    /('(?:[^'\\]|\\.)*')/g,
    '<span class="text-amber-300">$1</span>'
  );
  escaped = escaped.replace(
    /^(#\w+)/gm,
    '<span class="text-pink-400 font-semibold">$1</span>'
  );
  escaped = escaped.replace(
    /(\/\/.*$)/gm,
    '<span class="text-slate-500 italic">$1</span>'
  );
  escaped = escaped.replace(
    /(\/\*[\s\S]*?\*\/)/g,
    '<span class="text-slate-500 italic">$1</span>'
  );
  escaped = escaped.replace(
    /\b(\d+(?:\.\d+)?[fL]?)\b/g,
    '<span class="text-cyan-300">$1</span>'
  );

  const kwRegex = new RegExp(`\\b(${keywords.join("|")})\\b`, "g");
  escaped = escaped.replace(
    kwRegex,
    '<span class="text-violet-400 font-semibold">$1</span>'
  );

  return escaped;
}

interface CodeBlockProps {
  code: string;
  title?: string;
  /** show expected console output */
  output?: string;
}

export default function CodeBlock({ code, title, output }: CodeBlockProps) {
  const clean = useMemo(() => repairEscapes(code), [code]);
  const html = useMemo(() => highlight(clean), [clean]);
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(clean);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="my-4 w-full max-w-full overflow-hidden rounded-xl border border-slate-700/60 bg-slate-950 shadow-lg shadow-black/20">
      {(title || true) && (
        <div className="flex items-center justify-between gap-2 border-b border-slate-800 bg-slate-900/70 px-3 py-2">
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-red-500/80"></span>
            <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/80"></span>
            <span className="h-2.5 w-2.5 rounded-full bg-green-500/80"></span>
            <span className="ml-2 truncate text-[11px] font-medium uppercase tracking-wider text-slate-400">
              {title || "program.c"}
            </span>
          </div>
          <button
            onClick={copy}
            className="shrink-0 rounded-md border border-slate-700 px-2 py-1 text-[10px] font-semibold text-slate-400 transition hover:border-slate-600 hover:text-slate-200"
          >
            {copied ? "✓ Copied" : "Copy"}
          </button>
        </div>
      )}
      <pre className="max-w-full overflow-x-auto p-3 text-[12.5px] leading-relaxed text-slate-200 sm:p-4 sm:text-[13.5px]">
        <code
          className="whitespace-pre font-mono"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      </pre>
      {output && (
        <div className="border-t border-slate-800 bg-black/60 px-3 py-2.5 sm:px-4">
          <div className="mb-1 text-[10px] font-bold uppercase tracking-widest text-emerald-500">
            ▸ Output
          </div>
          <pre className="max-w-full overflow-x-auto whitespace-pre-wrap break-words font-mono text-[12px] leading-relaxed text-emerald-300 sm:text-[13px]">
            {output}
          </pre>
        </div>
      )}
    </div>
  );
}
