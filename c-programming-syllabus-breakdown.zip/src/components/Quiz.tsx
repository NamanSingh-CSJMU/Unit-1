import { useState } from "react";

export interface QuizQ {
  q: string;
  options: string[];
  answer: number;
  explain: string;
}

export default function Quiz({ questions }: { questions: QuizQ[] }) {
  const [picked, setPicked] = useState<(number | null)[]>(
    Array(questions.length).fill(null)
  );
  const [score, setScore] = useState<number | null>(null);

  const choose = (qi: number, oi: number) => {
    if (picked[qi] !== null) return;
    const next = [...picked];
    next[qi] = oi;
    setPicked(next);
  };

  const answeredAll = picked.every((p) => p !== null);

  const check = () => {
    let s = 0;
    picked.forEach((p, i) => {
      if (p === questions[i].answer) s++;
    });
    setScore(s);
  };

  const reset = () => {
    setPicked(Array(questions.length).fill(null));
    setScore(null);
  };

  return (
    <div className="rounded-2xl border border-violet-500/30 bg-violet-500/5 p-4 sm:p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-base font-bold text-violet-300 sm:text-lg">
          <span>🧠</span> Test Yourself ({questions.length} MCQs)
        </h3>
        {score !== null && (
          <span className="rounded-full bg-violet-500/20 px-3 py-1 text-xs font-bold text-violet-200">
            Score: {score} / {questions.length}
          </span>
        )}
      </div>

      <div className="space-y-4">
        {questions.map((q, qi) => {
          const sel = picked[qi];
          const revealed = sel !== null;
          return (
            <div
              key={qi}
              className="rounded-xl border border-slate-700 bg-slate-900/50 p-3.5"
            >
              <p className="mb-3 text-[13.5px] font-semibold leading-snug text-white sm:text-sm">
                <span className="mr-1.5 text-violet-400">Q{qi + 1}.</span>
                {q.q}
              </p>
              <div className="space-y-2">
                {q.options.map((op, oi) => {
                  const isCorrect = oi === q.answer;
                  const isPicked = sel === oi;
                  let cls =
                    "border-slate-700 bg-slate-800/40 text-slate-300 hover:border-slate-600";
                  if (revealed && isCorrect)
                    cls = "border-emerald-500/70 bg-emerald-500/15 text-emerald-200";
                  else if (revealed && isPicked)
                    cls = "border-red-500/70 bg-red-500/15 text-red-200";
                  else if (revealed)
                    cls = "border-slate-800 bg-slate-800/20 text-slate-500";
                  return (
                    <button
                      key={oi}
                      onClick={() => choose(qi, oi)}
                      disabled={revealed}
                      className={`flex w-full items-start gap-2.5 rounded-lg border p-2.5 text-left text-[13px] leading-snug transition sm:text-[13.5px] ${cls} ${
                        revealed ? "cursor-default" : "cursor-pointer"
                      }`}
                    >
                      <span className="mt-px flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-current text-[11px] font-bold">
                        {String.fromCharCode(65 + oi)}
                      </span>
                      <span className="min-w-0 break-words">{op}</span>
                      {revealed && isCorrect && (
                        <span className="ml-auto shrink-0 text-emerald-400">✓</span>
                      )}
                    </button>
                  );
                })}
              </div>
              {revealed && (
                <div className="mt-3 rounded-lg border border-slate-700/70 bg-slate-950/60 p-2.5 text-[13px] leading-relaxed text-slate-400">
                  <span className="font-semibold text-emerald-300">
                    Answer: {String.fromCharCode(65 + q.answer)}.{" "}
                  </span>
                  {q.explain}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {!answeredAll ? (
          <button
            disabled
            className="rounded-lg border border-slate-700 px-4 py-2 text-xs font-semibold text-slate-500"
          >
            Answer all to see score
          </button>
        ) : score === null ? (
          <button
            onClick={check}
            className="rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-violet-500/20 transition hover:from-violet-500 hover:to-fuchsia-500"
          >
            Check My Score →
          </button>
        ) : (
          <button
            onClick={reset}
            className="rounded-lg border border-violet-500/50 bg-violet-500/10 px-4 py-2 text-xs font-bold text-violet-200 transition hover:bg-violet-500/20"
          >
            ↻ Try Again
          </button>
        )}
      </div>
    </div>
  );
}
