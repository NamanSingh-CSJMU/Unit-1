import CodeBlock from "../components/CodeBlock";
import { Section, SubSection, NoteBox, InlineCode, Table } from "../components/UI";

export default function Chapter6() {
  return (
    <div className="space-y-2">
      <div className="mb-8 border-b border-slate-800 pb-6">
        <div className="mb-2 flex items-center gap-2">
          <span className="rounded-full bg-amber-500/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-amber-300">
            Chapter 6
          </span>
          <span className="text-xs text-slate-500">~ 20 min read</span>
        </div>
        <h1 className="mb-3 bg-gradient-to-r from-amber-300 via-orange-300 to-rose-300 bg-clip-text text-4xl font-extrabold text-transparent md:text-5xl">
          Looping Statements
        </h1>
        <p className="text-lg text-slate-400">
          Repeat statements with for, while, and do-while loops. Learn to control them using break, continue, and nesting.
        </p>
      </div>

      <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-5">
        <h3 className="mb-3 flex items-center gap-2 font-semibold text-amber-300">
          <span>🎯</span> Learning Objectives
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• Understand why loops are needed</li>
          <li>• Use <InlineCode>for</InlineCode>, <InlineCode>while</InlineCode>, and <InlineCode>do-while</InlineCode> loops</li>
          <li>• Control loops with <InlineCode>break</InlineCode> and <InlineCode>continue</InlineCode></li>
          <li>• Build nested loops (including nested for)</li>
        </ul>
      </div>

      <Section title="6.1 What is a Loop?">
        <p className="mb-4 leading-relaxed text-slate-300">
          A <strong className="text-white">loop</strong> is a control structure that repeats a block of
          statements as long as a given condition is true. Loops save you from writing the same code many times.
        </p>
        <p className="mb-3 leading-relaxed text-slate-300">
          C provides <strong>three</strong> types of loops:
        </p>
        <div className="grid gap-3 md:grid-cols-3">
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4">
            <h4 className="mb-2 font-semibold text-amber-300">for</h4>
            <p className="text-xs text-slate-400">When you know in advance how many times to repeat.</p>
          </div>
          <div className="rounded-lg border border-orange-500/30 bg-orange-500/5 p-4">
            <h4 className="mb-2 font-semibold text-orange-300">while</h4>
            <p className="text-xs text-slate-400">When you want to test the condition before each run.</p>
          </div>
          <div className="rounded-lg border border-rose-500/30 bg-rose-500/5 p-4">
            <h4 className="mb-2 font-semibold text-rose-300">do-while</h4>
            <p className="text-xs text-slate-400">When the body must run at least once.</p>
          </div>
        </div>
      </Section>

      <Section title="6.2 The for Loop">
        <p className="mb-3 leading-relaxed text-slate-300">
          The <InlineCode>for</InlineCode> loop is ideal when the number of iterations is known. Its syntax
          puts <em>initialization</em>, <em>condition</em>, and <em>update</em> all in one line.
        </p>
        <div className="mb-3 rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono text-sm">
          <span className="text-violet-300">for</span> (<span className="text-amber-300">init</span> ; <span className="text-cyan-300">condition</span> ; <span className="text-emerald-300">update</span>) {"{ ... }"}
        </div>

        <CodeBlock
          title="for_basic.c"
          code={`#include <stdio.h>

int main()
{
    // Print 1 to 5
    for (int i = 1; i <= 5; i++) {
        printf("%d ", i);
    }
    // Output: 1 2 3 4 5
    return 0;
}`}
        />

        <SubSection title="How a for Loop Works">
          <ol className="ml-6 list-decimal space-y-1.5 text-slate-300">
            <li><strong className="text-white">Initialization</strong> (<InlineCode>int i = 1</InlineCode>) — runs once.</li>
            <li><strong className="text-white">Condition</strong> (<InlineCode>i &lt;= 5</InlineCode>) — checked before each iteration.</li>
            <li>If true → execute the body.</li>
            <li><strong className="text-white">Update</strong> (<InlineCode>i++</InlineCode>) — runs after each iteration.</li>
            <li>Go back to step 2. If false → exit the loop.</li>
          </ol>
        </SubSection>

        <SubSection title="Example: Sum of 1 to 100">
          <CodeBlock
            code={`#include <stdio.h>

int main()
{
    int sum = 0;
    for (int i = 1; i <= 100; i++) {
        sum = sum + i;
    }
    printf("Sum 1 to 100 = %d\\n", sum);  // 5050
    return 0;
}`}
          />
        </SubSection>
      </Section>

      <Section title="6.3 The while Loop">
        <p className="mb-3 leading-relaxed text-slate-300">
          An <strong>entry-controlled</strong> loop. The condition is checked <em>before</em> the body runs.
          Use when you don't know how many times to loop.
        </p>
        <div className="mb-3 rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono text-sm">
          <span className="text-violet-300">while</span> (<span className="text-cyan-300">condition</span>) {"{ ... }"}
        </div>
        <CodeBlock
          title="while_basic.c"
          code={`#include <stdio.h>

int main()
{
    int i = 1;
    while (i <= 5) {
        printf("%d ", i);
        i++;
    }
    // Output: 1 2 3 4 5
    return 0;
}`}
        />
        <NoteBox type="warn" title="Infinite Loop Alert">
          Always make sure the loop variable changes so the condition eventually becomes false. Forgetting
          <InlineCode> i++ </InlineCode> inside a while loop causes an <strong>infinite loop</strong>.
        </NoteBox>
      </Section>

      <Section title="6.4 The do-while Loop">
        <p className="mb-3 leading-relaxed text-slate-300">
          An <strong>exit-controlled</strong> loop. The body runs <em>at least once</em>, then the condition
          is checked.
        </p>
        <div className="mb-3 rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono text-sm">
          <span className="text-violet-300">do</span> {"{ ... }"} <span className="text-violet-300">while</span> (<span className="text-cyan-300">condition</span>);
        </div>
        <CodeBlock
          title="dowhile.c"
          code={`#include <stdio.h>

int main()
{
    int n, sum = 0;

    do {
        printf("Enter a number (0 to stop): ");
        scanf("%d", &n);
        sum = sum + n;
    } while (n != 0);

    printf("Total sum = %d\\n", sum);
    return 0;
}`}
        />
        <NoteBox type="info">
          Notice the semicolon after <InlineCode>while(...);</InlineCode> — required in do-while!
        </NoteBox>
      </Section>

      <Section title="6.5 Comparing the Three Loops">
        <Table
          headers={["Feature", "for", "while", "do-while"]}
          rows={[
            ["Condition check", "Before body", "Before body", "After body"],
            ["Minimum runs", "0", "0", "1"],
            ["Best when", "Iterations known", "Iterations unknown", "Need at least 1 run"],
            ["Semicolon after", "No", "No", <span className="text-amber-300">Yes (after while)</span>],
            ["Syntax", "init; cond; update", "just condition", "do { } while;"],
          ]}
        />
      </Section>

      <Section title="6.6 The break Statement">
        <p className="mb-3 leading-relaxed text-slate-300">
          <InlineCode>break</InlineCode> immediately <strong>exits the innermost loop</strong> (or switch)
          in which it appears.
        </p>
        <CodeBlock
          title="break_example.c"
          code={`#include <stdio.h>

int main()
{
    for (int i = 1; i <= 10; i++) {
        if (i == 6) {
            break;          // exit loop when i == 6
        }
        printf("%d ", i);
    }
    // Output: 1 2 3 4 5
    return 0;
}`}
        />
      </Section>

      <Section title="6.7 The continue Statement">
        <p className="mb-3 leading-relaxed text-slate-300">
          <InlineCode>continue</InlineCode> <strong>skips the rest</strong> of the current iteration and
          jumps to the next iteration of the loop.
        </p>
        <CodeBlock
          title="continue_example.c"
          code={`#include <stdio.h>

int main()
{
    // Print only odd numbers 1..10
    for (int i = 1; i <= 10; i++) {
        if (i % 2 == 0) {
            continue;      // skip even numbers
        }
        printf("%d ", i);
    }
    // Output: 1 3 5 7 9
    return 0;
}`}
        />
        <NoteBox type="tip">
          • <InlineCode>break</InlineCode> = <strong>exit the whole loop</strong>.<br />
          • <InlineCode>continue</InlineCode> = <strong>skip to the next iteration</strong>.
        </NoteBox>
      </Section>

      <Section title="6.8 Nested Loops">
        <p className="mb-3 leading-relaxed text-slate-300">
          A <strong className="text-white">nested loop</strong> is a loop inside another loop. The inner
          loop runs <strong>fully</strong> for every single iteration of the outer loop.
        </p>
        <CodeBlock
          title="nested_loops.c"
          code={`#include <stdio.h>

int main()
{
    // Multiplication table (1 to 5) x (1 to 5)
    for (int i = 1; i <= 5; i++) {           // outer loop
        for (int j = 1; j <= 5; j++) {       // inner loop
            printf("%3d", i * j);
        }
        printf("\\n");
    }
    return 0;
}`}
        />
      </Section>

      <Section title="6.9 Nested for Loop — Classic Examples">
        <SubSection title="Example 1: Pattern (right triangle)">
          <CodeBlock
            title="pattern.c"
            code={`#include <stdio.h>

int main()
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            printf("* ");
        }
        printf("\\n");
    }
    // Output:
    // *
    // * *
    // * * *
    // * * * *
    // * * * * *
    return 0;
}`}
          />
        </SubSection>

        <SubSection title="Example 2: Number Pyramid">
          <CodeBlock
            code={`#include <stdio.h>

int main()
{
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        // print spaces
        for (int s = 1; s <= rows - i; s++) {
            printf(" ");
        }
        // print numbers 1..i
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        printf("\\n");
    }
    return 0;
}`}
          />
        </SubSection>

        <SubSection title="Example 3: Prime Numbers 1 to N">
          <CodeBlock
            title="prime.c"
            code={`#include <stdio.h>

int main()
{
    int n = 30;
    printf("Primes up to %d:\\n", n);

    for (int num = 2; num <= n; num++) {
        int isPrime = 1;
        for (int d = 2; d * d <= num; d++) {
            if (num % d == 0) {
                isPrime = 0;
                break;
            }
        }
        if (isPrime) {
            printf("%d ", num);
        }
    }
    printf("\\n");
    return 0;
}`}
          />
        </SubSection>
      </Section>

      {/* Summary */}
      <div className="mt-10 rounded-xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-6">
        <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-white">
          <span>📝</span> Chapter Summary
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• <strong className="text-white">for:</strong> <InlineCode>for (init; cond; update) {"{ ... }"}</InlineCode> — use when iteration count is known.</li>
          <li>• <strong className="text-white">while:</strong> <InlineCode>while (cond) {"{ ... }"}</InlineCode> — entry-controlled.</li>
          <li>• <strong className="text-white">do-while:</strong> runs at least once, then checks condition.</li>
          <li>• <strong className="text-white">break:</strong> exits the loop immediately.</li>
          <li>• <strong className="text-white">continue:</strong> skips the rest of this iteration.</li>
          <li>• <strong className="text-white">Nested loops:</strong> inner loop runs completely for each outer iteration.</li>
        </ul>
      </div>

      {/* Unit complete banner */}
      <div className="mt-8 overflow-hidden rounded-2xl border border-emerald-500/40 bg-gradient-to-r from-emerald-900/40 via-cyan-900/40 to-violet-900/40 p-6 text-center">
        <div className="mb-2 text-4xl">🎉</div>
        <h3 className="mb-1 text-2xl font-bold text-white">Unit 1 Complete!</h3>
        <p className="text-slate-300">
          You've covered the fundamentals of C programming and control structures. Keep practicing with
          small programs to solidify your understanding.
        </p>
      </div>
    </div>
  );
}
