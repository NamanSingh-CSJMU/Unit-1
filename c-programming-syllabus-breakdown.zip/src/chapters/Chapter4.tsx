import CodeBlock from "../components/CodeBlock";
import { Section, SubSection, NoteBox, InlineCode, Table } from "../components/UI";

export default function Chapter4() {
  return (
    <div className="space-y-2">
      <div className="mb-8 border-b border-slate-800 pb-6">
        <div className="mb-2 flex items-center gap-2">
          <span className="rounded-full bg-fuchsia-500/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-fuchsia-300">
            Chapter 4
          </span>
          <span className="text-xs text-slate-500">~ 12 min read</span>
        </div>
        <h1 className="mb-3 bg-gradient-to-r from-fuchsia-300 via-pink-300 to-amber-300 bg-clip-text text-4xl font-extrabold text-transparent md:text-5xl">
          Input &amp; Output Operations
        </h1>
        <p className="text-lg text-slate-400">
          Learn how to read user input and display results using C's I/O functions, especially single-character I/O.
        </p>
      </div>

      <div className="rounded-xl border border-fuchsia-500/30 bg-fuchsia-500/5 p-5">
        <h3 className="mb-3 flex items-center gap-2 font-semibold text-fuchsia-300">
          <span>🎯</span> Learning Objectives
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• Understand C's I/O library (stdio.h)</li>
          <li>• Use single-character I/O: <InlineCode>getchar()</InlineCode>, <InlineCode>putchar()</InlineCode>, <InlineCode>getche()</InlineCode>, <InlineCode>getch()</InlineCode></li>
          <li>• Use formatted I/O: <InlineCode>scanf()</InlineCode> and <InlineCode>printf()</InlineCode></li>
          <li>• Know common format specifiers</li>
        </ul>
      </div>

      <Section title="4.1 The stdio.h Library">
        <p className="mb-4 leading-relaxed text-slate-300">
          All standard input/output functions in C are defined in the header file{" "}
          <InlineCode>&lt;stdio.h&gt;</InlineCode> (Standard Input Output). You must include it using{" "}
          <InlineCode>#include &lt;stdio.h&gt;</InlineCode> at the top of your program.
        </p>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-lg border border-slate-700 bg-slate-800/50 p-4">
            <h4 className="mb-2 font-semibold text-fuchsia-300">📥 Input Functions</h4>
            <ul className="space-y-1 text-sm text-slate-300">
              <li>• <InlineCode>getchar()</InlineCode> — read one char</li>
              <li>• <InlineCode>getche()</InlineCode> — read with echo</li>
              <li>• <InlineCode>getch()</InlineCode> — read without echo</li>
              <li>• <InlineCode>scanf()</InlineCode> — formatted input</li>
            </ul>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-800/50 p-4">
            <h4 className="mb-2 font-semibold text-fuchsia-300">📤 Output Functions</h4>
            <ul className="space-y-1 text-sm text-slate-300">
              <li>• <InlineCode>putchar()</InlineCode> — print one char</li>
              <li>• <InlineCode>puts()</InlineCode> — print a string</li>
              <li>• <InlineCode>printf()</InlineCode> — formatted output</li>
            </ul>
          </div>
        </div>
      </Section>

      <Section title="4.2 Single Character I/O">
        <p className="mb-4 leading-relaxed text-slate-300">
          Single-character I/O functions handle exactly one character at a time. They are simple but useful in
          many situations (e.g., menus, reading one key).
        </p>

        <SubSection title="getchar() — Read a character from keyboard">
          <p className="mb-2 text-sm text-slate-300">
            Reads one character from standard input. User must press <strong>Enter</strong> after typing the character.
          </p>
          <CodeBlock
            code={`char ch;
ch = getchar();   // wait for input + Enter`}
          />
        </SubSection>

        <SubSection title="putchar() — Print a character">
          <p className="mb-2 text-sm text-slate-300">
            Prints one character to standard output.
          </p>
          <CodeBlock
            title="single_char.c"
            code={`#include <stdio.h>

int main()
{
    char ch;
    printf("Enter a character: ");
    ch = getchar();

    printf("You entered: ");
    putchar(ch);
    printf("\\n");

    return 0;
}`}
          />
        </SubSection>

        <SubSection title="getche() — Read a character with echo (immediate)">
          <p className="mb-2 text-sm text-slate-300">
            Reads a character <strong>immediately</strong> after typing, without waiting for Enter. The typed
            character is displayed (echoed). Defined in <InlineCode>&lt;conio.h&gt;</InlineCode> (DOS/Windows).
          </p>
          <CodeBlock
            code={`#include <stdio.h>
#include <conio.h>

int main()
{
    char ch;
    printf("Press any key: ");
    ch = getche();   // echoes the character
    return 0;
}`}
          />
        </SubSection>

        <SubSection title="getch() — Read a character without echo (hidden)">
          <p className="mb-2 text-sm text-slate-300">
            Reads a character immediately without displaying it. Commonly used for password input.
          </p>
          <CodeBlock
            code={`#include <stdio.h>
#include <conio.h>

int main()
{
    char password[20];
    printf("Enter password: ");
    // reads hidden chars
    for (int i = 0; i < 4; i++)
        password[i] = getch();
    printf("\\nPassword accepted.\\n");
    return 0;
}`}
          />
        </SubSection>

        <SubSection title="Comparison Table">
          <Table
            headers={["Function", "Reads", "Echoes?", "Needs Enter?", "Header"]}
            rows={[
              [<InlineCode>getchar()</InlineCode>, "1 char", "Yes", "Yes", "<stdio.h>"],
              [<InlineCode>getche()</InlineCode>, "1 char", "Yes", "No", "<conio.h>"],
              [<InlineCode>getch()</InlineCode>, "1 char", "No", "No", "<conio.h>"],
            ]}
          />
        </SubSection>
      </Section>

      <Section title="4.3 Formatted Input — scanf()">
        <p className="mb-3 leading-relaxed text-slate-300">
          <InlineCode>scanf()</InlineCode> reads formatted input from the user.
        </p>
        <div className="mb-3 rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono text-sm">
          <span className="text-violet-300">scanf</span>(<span className="text-amber-300">"format_string"</span>, <span className="text-emerald-300">&amp;variable</span>);
        </div>
        <NoteBox type="warn" title="Don't forget the &">
          Always use <InlineCode>&amp;</InlineCode> before a variable in <InlineCode>scanf()</InlineCode>
          (except for strings/arrays). Forgetting it leads to undefined behavior!
        </NoteBox>

        <SubSection title="Common Format Specifiers">
          <Table
            headers={["Specifier", "Meaning", "Example"]}
            rows={[
              [<InlineCode>%c</InlineCode>, "Single character", "scanf(\"%c\", &ch);"],
              [<InlineCode>%d</InlineCode>, "Integer (decimal)", "scanf(\"%d\", &num);"],
              [<InlineCode>%f</InlineCode>, "Floating point", "scanf(\"%f\", &price);"],
              [<InlineCode>%lf</InlineCode>, "Double", "scanf(\"%lf\", &value);"],
              [<InlineCode>%s</InlineCode>, "String (no &)", "scanf(\"%s\", name);"],
              [<InlineCode>%o</InlineCode>, "Octal integer", "scanf(\"%o\", &num);"],
              [<InlineCode>%x</InlineCode>, "Hexadecimal", "scanf(\"%x\", &num);"],
            ]}
          />
        </SubSection>

        <CodeBlock
          title="scanf_example.c"
          code={`#include <stdio.h>

int main()
{
    int age;
    float height;
    char grade;
    char name[50];

    printf("Enter name, age, height, grade:\\n");
    scanf("%s %d %f %c", name, &age, &height, &grade);

    printf("\\n--- Your Details ---\\n");
    printf("Name   : %s\\n", name);
    printf("Age    : %d\\n", age);
    printf("Height : %.2f\\n", height);
    printf("Grade  : %c\\n", grade);

    return 0;
}`}
        />
      </Section>

      <Section title="4.4 Formatted Output — printf()">
        <p className="mb-3 leading-relaxed text-slate-300">
          <InlineCode>printf()</InlineCode> prints formatted text to the console.
        </p>
        <div className="mb-3 rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono text-sm">
          <span className="text-violet-300">printf</span>(<span className="text-amber-300">"format string with %specifiers"</span>, <span className="text-emerald-300">variables...</span>);
        </div>

        <SubSection title="Useful Format Flags">
          <Table
            headers={["Flag / Specifier", "Effect", "Example Output"]}
            rows={[
              [<InlineCode>%5d</InlineCode>, "Width of 5, right-aligned", "<code>___10</code> (underscores = spaces)"],
              [<InlineCode>%-5d</InlineCode>, "Width 5, left-aligned", "<code>10___</code>"],
              [<InlineCode>%05d</InlineCode>, "Pad with zeros", "<code>00010</code>"],
              [<InlineCode>%.2f</InlineCode>, "2 decimal places", "<code>3.14</code>"],
              [<InlineCode>%10.2f</InlineCode>, "Width 10, 2 decimals", "<code>______3.14</code>"],
            ]}
          />
        </SubSection>

        <SubSection title="Escape Sequences">
          <Table
            headers={["Sequence", "Meaning"]}
            rows={[
              [<InlineCode>\\n</InlineCode>, "Newline"],
              [<InlineCode>\\t</InlineCode>, "Horizontal tab"],
              [<InlineCode>\\\\</InlineCode>, "Backslash"],
              [<InlineCode>\\"</InlineCode>, "Double quote"],
              [<InlineCode>\\'</InlineCode>, "Single quote"],
              [<InlineCode>\\0</InlineCode>, "Null character"],
              [<InlineCode>\\b</InlineCode>, "Backspace"],
              [<InlineCode>\\r</InlineCode>, "Carriage return"],
            ]}
          />
        </SubSection>

        <CodeBlock
          title="printf_format.c"
          code={`#include <stdio.h>

int main()
{
    int    marks = 85;
    float  avg   = 87.5678;
    char   grade = 'A';

    printf("Marks   : %d\\n", marks);
    printf("Avg     : %.2f\\n", avg);          // 87.57
    printf("Grade   : %c\\n", grade);
    printf("Padded  : %05d\\n", marks);        // 00085
    printf("Tabbed  : %d\\t%s\\n", marks, "PASS");

    return 0;
}`}
        />
      </Section>

      {/* Summary */}
      <div className="mt-10 rounded-xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-6">
        <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-white">
          <span>📝</span> Chapter Summary
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• <strong className="text-white">stdio.h</strong> is required for all I/O functions.</li>
          <li>• <strong className="text-white">Single-char I/O:</strong> <InlineCode>getchar</InlineCode>/<InlineCode>putchar</InlineCode>, <InlineCode>getche</InlineCode>, <InlineCode>getch</InlineCode>.</li>
          <li>• <strong className="text-white">scanf</strong>: formatted input. Always use <InlineCode>&amp;</InlineCode> before variables.</li>
          <li>• <strong className="text-white">printf</strong>: formatted output with specifiers like %d, %f, %c, %s.</li>
          <li>• <strong className="text-white">Escape sequences:</strong> \n, \t, \\, \", etc. for special characters.</li>
        </ul>
      </div>

      <div className="mt-6 rounded-xl border border-violet-500/30 bg-violet-500/5 p-5">
        <h3 className="mb-3 flex items-center gap-2 font-semibold text-violet-300">
          <span>🧠</span> Quick Check
        </h3>
        <div className="space-y-4 text-sm text-slate-300">
          <div className="rounded-lg border border-slate-700 bg-slate-900/40 p-3">
            <p className="mb-1 font-semibold text-white">Q1. Which function reads a char without echoing it?</p>
            <details className="text-slate-400">
              <summary className="cursor-pointer text-emerald-300 hover:text-emerald-200">Show answer</summary>
              <p className="mt-1"><InlineCode>getch()</InlineCode> (from conio.h).</p>
            </details>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-900/40 p-3">
            <p className="mb-1 font-semibold text-white">Q2. Why do we write <InlineCode>&amp;x</InlineCode> in scanf but not in printf?</p>
            <details className="text-slate-400">
              <summary className="cursor-pointer text-emerald-300 hover:text-emerald-200">Show answer</summary>
              <p className="mt-1">scanf needs the <em>address</em> of the variable to store the value there. printf only needs the value itself.</p>
            </details>
          </div>
        </div>
      </div>
    </div>
  );
}
