import CodeBlock from "../components/CodeBlock";
import { Section, SubSection, NoteBox, InlineCode, Table } from "../components/UI";

export default function Chapter3() {
  return (
    <div className="space-y-2">
      <div className="mb-8 border-b border-slate-800 pb-6">
        <div className="mb-2 flex items-center gap-2">
          <span className="rounded-full bg-sky-500/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-sky-300">
            Chapter 3
          </span>
          <span className="text-xs text-slate-500">~ 15 min read</span>
        </div>
        <h1 className="mb-3 bg-gradient-to-r from-sky-300 via-blue-300 to-violet-300 bg-clip-text text-4xl font-extrabold text-transparent md:text-5xl">
          Operators &amp; Operator Precedence
        </h1>
        <p className="text-lg text-slate-400">
          Operators are the building blocks of expressions. Learn every operator in C and the order in which they are evaluated.
        </p>
      </div>

      <div className="rounded-xl border border-sky-500/30 bg-sky-500/5 p-5">
        <h3 className="mb-3 flex items-center gap-2 font-semibold text-sky-300">
          <span>🎯</span> Learning Objectives
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• Understand what operators and operands are</li>
          <li>• Know all categories of operators in C</li>
          <li>• Use each operator correctly with examples</li>
          <li>• Master operator precedence and associativity</li>
        </ul>
      </div>

      <Section title="3.1 What are Operators?">
        <p className="mb-4 leading-relaxed text-slate-300">
          An <strong className="text-white">operator</strong> is a symbol that tells the compiler to perform a specific
          mathematical or logical operation on <strong className="text-white">operands</strong> (values or variables).
        </p>
        <div className="rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono">
          <span className="text-amber-300">a</span>{" "}
          <span className="text-emerald-300">+</span>{" "}
          <span className="text-amber-300">b</span>
          <p className="mt-2 text-xs text-slate-500">
            <span className="text-amber-300">a</span> and <span className="text-amber-300">b</span> are
            <span className="text-amber-300"> operands</span> &nbsp;|&nbsp;{" "}
            <span className="text-emerald-300">+</span> is the <span className="text-emerald-300">operator</span>
          </p>
        </div>
        <p className="mt-4 leading-relaxed text-slate-300">
          Operators in C are classified based on the <strong>type of operation</strong> they perform and the
          number of operands they need (<strong>unary</strong>: 1 operand, <strong>binary</strong>: 2 operands,
          <strong>ternary</strong>: 3 operands).
        </p>
      </Section>

      <Section title="3.2 Arithmetic Operators">
        <p className="mb-3 leading-relaxed text-slate-300">
          Used for basic mathematical calculations. All are <strong>binary operators</strong> except{" "}
          <InlineCode>+</InlineCode> and <InlineCode>-</InlineCode> which can be unary.
        </p>
        <Table
          headers={["Operator", "Meaning", "Example", "Result"]}
          rows={[
            [<InlineCode>+</InlineCode>, "Addition", "a + b", "10 + 3 = 13"],
            [<InlineCode>-</InlineCode>, "Subtraction", "a - b", "10 - 3 = 7"],
            [<InlineCode>*</InlineCode>, "Multiplication", "a * b", "10 * 3 = 30"],
            [<InlineCode>/</InlineCode>, "Division", "a / b", "10 / 3 = 3 (integer)"],
            [<InlineCode>%</InlineCode>, "Modulus (remainder)", "a % b", "10 % 3 = 1"],
          ]}
        />
        <NoteBox type="warn" title="About Division & Modulus">
          <InlineCode>/</InlineCode> on integers truncates the decimal part (10/3 = 3, not 3.33). To get a decimal
          result, cast at least one operand: <InlineCode>10.0 / 3 = 3.333...</InlineCode>.<br />
          <InlineCode>%</InlineCode> works only with integers, not floats.
        </NoteBox>
        <CodeBlock
          title="arithmetic.c"
          code={`#include <stdio.h>

int main()
{
    int a = 10, b = 3;
    printf("a + b = %d\\n", a + b);
    printf("a - b = %d\\n", a - b);
    printf("a * b = %d\\n", a * b);
    printf("a / b = %d\\n", a / b);   // integer division
    printf("a %% b = %d\\n", a % b);
    return 0;
}`}
        />
      </Section>

      <Section title="3.3 Relational (Comparison) Operators">
        <p className="mb-3 leading-relaxed text-slate-300">
          Used to compare two values. They always return <strong>1</strong> (true) or <strong>0</strong> (false).
        </p>
        <Table
          headers={["Operator", "Meaning", "Example", "Result"]}
          rows={[
            [<InlineCode>==</InlineCode>, "Equal to", "5 == 5", "1 (true)"],
            [<InlineCode>!=</InlineCode>, "Not equal to", "5 != 5", "0 (false)"],
            [<InlineCode>&gt;</InlineCode>, "Greater than", "7 &gt; 3", "1 (true)"],
            [<InlineCode>&lt;</InlineCode>, "Less than", "7 &lt; 3", "0 (false)"],
            [<InlineCode>&gt;=</InlineCode>, "Greater or equal", "5 &gt;= 5", "1 (true)"],
            [<InlineCode>&lt;=</InlineCode>, "Less or equal", "5 &lt;= 3", "0 (false)"],
          ]}
        />
        <NoteBox type="warn" title="Common Mistake">
          Don't confuse <InlineCode>=</InlineCode> (assignment) with <InlineCode>==</InlineCode> (equality).
          <br />
          <InlineCode>x = 5</InlineCode> → assigns 5 to x. <InlineCode>x == 5</InlineCode> → checks if x equals 5.
        </NoteBox>
      </Section>

      <Section title="3.4 Logical Operators">
        <p className="mb-3 leading-relaxed text-slate-300">
          Used to combine multiple conditions. Always return 0 or 1.
        </p>
        <Table
          headers={["Operator", "Meaning", "Example"]}
          rows={[
            [<InlineCode>&amp;&amp;</InlineCode>, "Logical AND", "(a &gt; 0) &amp;&amp; (b &gt; 0)"],
            [<InlineCode>||</InlineCode>, "Logical OR", "(a &gt; 0) || (b &gt; 0)"],
            [<InlineCode>!</InlineCode>, "Logical NOT (unary)", "! (a &gt; 0)"],
          ]}
        />
        <CodeBlock
          code={`#include <stdio.h>

int main()
{
    int age = 25;
    int hasID = 1;

    if (age >= 18 && hasID)
        printf("Entry allowed\\n");
    else
        printf("Entry denied\\n");

    return 0;
}`}
        />
      </Section>

      <Section title="3.5 Assignment Operators">
        <p className="mb-3 leading-relaxed text-slate-300">
          Used to assign values to variables. Compound assignment operators are shortcuts.
        </p>
        <Table
          headers={["Operator", "Equivalent", "Example"]}
          rows={[
            [<InlineCode>=</InlineCode>, "Simple assign", "a = 5"],
            [<InlineCode>+=</InlineCode>, "a = a + b", "a += 3"],
            [<InlineCode>-=</InlineCode>, "a = a - b", "a -= 3"],
            [<InlineCode>*=</InlineCode>, "a = a * b", "a *= 3"],
            [<InlineCode>/=</InlineCode>, "a = a / b", "a /= 3"],
            [<InlineCode>%=</InlineCode>, "a = a % b", "a %= 3"],
          ]}
        />
      </Section>

      <Section title="3.6 Increment &amp; Decrement Operators">
        <p className="mb-3 leading-relaxed text-slate-300">
          Unary operators that increase or decrease a variable by 1. They come in two forms:
        </p>
        <Table
          headers={["Operator", "Type", "Effect"]}
          rows={[
            [<InlineCode>++a</InlineCode>, "Pre-increment", "Increment first, then use"],
            [<InlineCode>a++</InlineCode>, "Post-increment", "Use first, then increment"],
            [<InlineCode>--a</InlineCode>, "Pre-decrement", "Decrement first, then use"],
            [<InlineCode>a--</InlineCode>, "Post-decrement", "Use first, then decrement"],
          ]}
        />
        <CodeBlock
          title="increment.c"
          code={`#include <stdio.h>

int main()
{
    int a = 5, b = 5;
    int x = ++a;    // a becomes 6, then x = 6
    int y = b++;    // y = 5, then b becomes 6

    printf("a = %d, x = %d\\n", a, x);  // 6, 6
    printf("b = %d, y = %d\\n", b, y);  // 6, 5
    return 0;
}`}
        />
      </Section>

      <Section title="3.7 Bitwise Operators">
        <p className="mb-3 leading-relaxed text-slate-300">
          Operate on individual bits of integer data. Rare in beginner code but important for systems programming.
        </p>
        <Table
          headers={["Operator", "Meaning", "Example"]}
          rows={[
            [<InlineCode>&amp;</InlineCode>, "Bitwise AND", "a & b"],
            [<InlineCode>|</InlineCode>, "Bitwise OR", "a | b"],
            [<InlineCode>^</InlineCode>, "Bitwise XOR", "a ^ b"],
            [<InlineCode>~</InlineCode>, "Bitwise NOT", "~a"],
            [<InlineCode>&lt;&lt;</InlineCode>, "Left shift", "a &lt;&lt; 2"],
            [<InlineCode>&gt;&gt;</InlineCode>, "Right shift", "a &gt;&gt; 2"],
          ]}
        />
      </Section>

      <Section title="3.8 Conditional (Ternary) Operator">
        <p className="mb-3 leading-relaxed text-slate-300">
          A shorthand for if-else. It takes <strong>three</strong> operands.
        </p>
        <div className="mb-4 rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono text-sm">
          <span className="text-violet-300">condition</span>{" "}
          <span className="text-slate-500">?</span>{" "}
          <span className="text-emerald-300">expr_if_true</span>{" "}
          <span className="text-slate-500">:</span>{" "}
          <span className="text-amber-300">expr_if_false</span>
        </div>
        <CodeBlock
          code={`int a = 10, b = 20;
int max = (a > b) ? a : b;   // max = 20`}
        />
      </Section>

      <Section title="3.9 Other Important Operators">
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-lg border border-slate-700 bg-slate-800/50 p-4">
            <h4 className="mb-2 font-semibold text-sky-300">sizeof operator</h4>
            <p className="text-sm text-slate-400">Returns the size (in bytes) of a type or variable.</p>
            <code className="mt-2 block font-mono text-xs text-emerald-300">sizeof(int) → 4</code>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-800/50 p-4">
            <h4 className="mb-2 font-semibold text-sky-300">&amp; (address-of)</h4>
            <p className="text-sm text-slate-400">Returns memory address of a variable.</p>
            <code className="mt-2 block font-mono text-xs text-emerald-300">&amp;x</code>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-800/50 p-4">
            <h4 className="mb-2 font-semibold text-sky-300">* (dereference / pointer)</h4>
            <p className="text-sm text-slate-400">Access value at an address (pointer).</p>
            <code className="mt-2 block font-mono text-xs text-emerald-300">*ptr</code>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-800/50 p-4">
            <h4 className="mb-2 font-semibold text-sky-300">, (comma)</h4>
            <p className="text-sm text-slate-400">Separates multiple expressions; evaluates left to right.</p>
            <code className="mt-2 block font-mono text-xs text-emerald-300">a = 1, b = 2</code>
          </div>
        </div>
      </Section>

      <Section title="3.10 Operator Precedence &amp; Associativity">
        <p className="mb-3 leading-relaxed text-slate-300">
          <strong className="text-white">Precedence</strong> determines which operator is evaluated first when multiple
          operators appear in an expression. <strong className="text-white">Associativity</strong> resolves ties
          when two operators have the same precedence (Left-to-Right or Right-to-Left).
        </p>

        <div className="overflow-x-auto rounded-lg border border-slate-700">
          <table className="w-full text-sm">
            <thead className="bg-slate-800/80 text-slate-200">
              <tr>
                <th className="px-3 py-2 text-left">Precedence</th>
                <th className="px-3 py-2 text-left">Operator(s)</th>
                <th className="px-3 py-2 text-left">Associativity</th>
              </tr>
            </thead>
            <tbody className="text-slate-300">
              {[
                ["1 (Highest)", "() [] -> .", "Left → Right"],
                ["2", "++ -- ! ~ + - * & sizeof (unary)", "Right → Left"],
                ["3", "* / %", "Left → Right"],
                ["4", "+ -", "Left → Right"],
                ["5", "<< >>", "Left → Right"],
                ["6", "< <= > >=", "Left → Right"],
                ["7", "== !=", "Left → Right"],
                ["8", "& (bitwise)", "Left → Right"],
                ["9", "^ (bitwise)", "Left → Right"],
                ["10", "| (bitwise)", "Left → Right"],
                ["11", "&&", "Left → Right"],
                ["12", "||", "Left → Right"],
                ["13", "?: (ternary)", "Right → Left"],
                ["14", "= += -= *= /= %= (assignment)", "Right → Left"],
                ["15 (Lowest)", ", (comma)", "Left → Right"],
              ].map((r, i) => (
                <tr key={i} className="border-t border-slate-800 bg-slate-900/40">
                  <td className="px-3 py-2 font-semibold text-emerald-300">{r[0]}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r[1]}</td>
                  <td className="px-3 py-2 text-xs text-slate-400">{r[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <NoteBox type="tip" title="Use Parentheses">
          When in doubt, use <InlineCode>( )</InlineCode> to make your intentions clear. It also improves readability.
          <br />
          Example: <InlineCode>(a + b) * c</InlineCode> instead of relying on precedence.
        </NoteBox>

        <SubSection title="Example: Evaluating an Expression">
          <CodeBlock
            title="precedence.c"
            code={`#include <stdio.h>

int main()
{
    int a = 10, b = 5, c = 2;
    int result;

    // * and / before +
    result = a + b * c;         // 10 + (5*2) = 20
    printf("a + b * c     = %d\\n", result);

    // Same precedence → left to right
    result = a - b - c;         // (10 - 5) - 2 = 3
    printf("a - b - c     = %d\\n", result);

    // Parentheses override precedence
    result = (a + b) * c;       // (10+5) * 2 = 30
    printf("(a+b) * c     = %d\\n", result);

    // Unary before binary
    result = -a + b;            // (-10) + 5 = -5
    printf("-a + b        = %d\\n", result);

    return 0;
}`}
          />
        </SubSection>
      </Section>

      {/* Summary */}
      <div className="mt-10 rounded-xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-6">
        <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-white">
          <span>📝</span> Chapter Summary
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• <strong className="text-white">Arithmetic:</strong> +, -, *, /, %</li>
          <li>• <strong className="text-white">Relational:</strong> ==, !=, &gt;, &lt;, &gt;=, &lt;=</li>
          <li>• <strong className="text-white">Logical:</strong> &amp;&amp;, ||, !</li>
          <li>• <strong className="text-white">Assignment:</strong> =, +=, -=, *=, /=, %=</li>
          <li>• <strong className="text-white">Increment/Decrement:</strong> ++, -- (pre/post)</li>
          <li>• <strong className="text-white">Bitwise:</strong> &amp;, |, ^, ~, &lt;&lt;, &gt;&gt;</li>
          <li>• <strong className="text-white">Ternary:</strong> ? :</li>
          <li>• <strong className="text-white">Precedence:</strong> Unary &gt; Multiplicative &gt; Additive &gt; Relational &gt; Logical &gt; Assignment</li>
        </ul>
      </div>
    </div>
  );
}
