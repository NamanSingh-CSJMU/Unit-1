import CodeBlock from "../components/CodeBlock";
import { Section, SubSection, NoteBox, InlineCode, Table } from "../components/UI";

export default function Chapter2() {
  return (
    <div className="space-y-2">
      <div className="mb-8 border-b border-slate-800 pb-6">
        <div className="mb-2 flex items-center gap-2">
          <span className="rounded-full bg-cyan-500/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-cyan-300">
            Chapter 2
          </span>
          <span className="text-xs text-slate-500">~ 18 min read</span>
        </div>
        <h1 className="mb-3 bg-gradient-to-r from-cyan-300 via-sky-300 to-emerald-300 bg-clip-text text-4xl font-extrabold text-transparent md:text-5xl">
          Identifiers, Keywords, Data Types &amp; Variables
        </h1>
        <p className="text-lg text-slate-400">
          Learn how to name things in C, the reserved words you cannot use, how data is stored, and how to declare variables and constants.
        </p>
      </div>

      <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/5 p-5">
        <h3 className="mb-3 flex items-center gap-2 font-semibold text-cyan-300">
          <span>🎯</span> Learning Objectives
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• Understand what identifiers are and their naming rules</li>
          <li>• Know the list of C keywords</li>
          <li>• Master simple data types and their sizes/ranges</li>
          <li>• Understand data type modifiers and their effect</li>
          <li>• Declare variables and constants correctly</li>
        </ul>
      </div>

      <Section title="2.1 Identifiers">
        <p className="mb-4 leading-relaxed text-slate-300">
          An <strong className="text-white">identifier</strong> is a name given to a variable, function, array,
          or any user-defined entity in a C program. Identifiers help us refer to memory locations in our code.
        </p>

        <SubSection title="Rules for Naming Identifiers">
          <ol className="list-inside list-decimal space-y-2 text-slate-300">
            <li>Must begin with a <strong className="text-white">letter (A-Z, a-z)</strong> or <strong className="text-white">underscore (_)</strong>.</li>
            <li>After the first character, it may contain <strong className="text-white">letters, digits, or underscores</strong>.</li>
            <li><strong className="text-red-300">Cannot</strong> start with a digit.</li>
            <li><strong className="text-red-300">Cannot</strong> contain whitespace or special characters (except <InlineCode>_</InlineCode>).</li>
            <li>Length: Traditionally only first <strong>31 characters</strong> are significant (ANSI C), though modern compilers allow more.</li>
            <li><strong className="text-red-300">Cannot</strong> be a keyword.</li>
            <li>C is <strong className="text-amber-300">case-sensitive</strong>: <InlineCode>Age</InlineCode>, <InlineCode>age</InlineCode>, and <InlineCode>AGE</InlineCode> are three different identifiers.</li>
          </ol>
        </SubSection>

        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4">
            <h4 className="mb-3 font-semibold text-emerald-300">✅ Valid Identifiers</h4>
            <ul className="space-y-1.5 font-mono text-sm text-slate-300">
              <li>• <span className="text-emerald-300">age</span></li>
              <li>• <span className="text-emerald-300">_count</span></li>
              <li>• <span className="text-emerald-300">student_name</span></li>
              <li>• <span className="text-emerald-300">rollNo123</span></li>
              <li>• <span className="text-emerald-300">MAX_SIZE</span></li>
              <li>• <span className="text-emerald-300">temp99</span></li>
            </ul>
          </div>
          <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-4">
            <h4 className="mb-3 font-semibold text-red-300">❌ Invalid Identifiers</h4>
            <ul className="space-y-1.5 font-mono text-sm text-slate-300">
              <li>• <del>2ndValue</del> <span className="text-xs text-slate-500">(starts with digit)</span></li>
              <li>• <del>user@name</del> <span className="text-xs text-slate-500">(special char)</span></li>
              <li>• <del>total sum</del> <span className="text-xs text-slate-500">(has space)</span></li>
              <li>• <del>float</del> <span className="text-xs text-slate-500">(keyword)</span></li>
              <li>• <del>my-name</del> <span className="text-xs text-slate-500">(hyphen not allowed)</span></li>
            </ul>
          </div>
        </div>
      </Section>

      <Section title="2.2 Keywords">
        <p className="mb-4 leading-relaxed text-slate-300">
          <strong className="text-white">Keywords</strong> are reserved words that have a predefined meaning
          to the C compiler. They <strong className="text-red-300">cannot</strong> be used as identifiers.
          C has <strong className="text-white">32 keywords</strong> (in standard C). All are written in <strong>lowercase</strong>.
        </p>

        <div className="my-5 grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {[
            "auto", "break", "case", "char", "const", "continue",
            "default", "do", "double", "else", "enum", "extern",
            "float", "for", "goto", "if", "int", "long",
            "register", "return", "short", "signed", "sizeof", "static",
            "struct", "switch", "typedef", "union", "unsigned", "void",
            "volatile", "while",
          ].map((k) => (
            <div
              key={k}
              className="rounded-lg border border-slate-700 bg-slate-900/60 px-2 py-1.5 text-center font-mono text-sm text-violet-300"
            >
              {k}
            </div>
          ))}
        </div>

        <NoteBox type="warn" title="Important">
          Never use a keyword as a variable or function name. For example,{" "}
          <InlineCode>int float = 5;</InlineCode> is a compilation error because{" "}
          <InlineCode>float</InlineCode> is a keyword.
        </NoteBox>
      </Section>

      <Section title="2.3 Simple Data Types">
        <p className="mb-4 leading-relaxed text-slate-300">
          A <strong className="text-white">data type</strong> specifies the kind of data a variable can hold.
          It determines the amount of memory allocated and the range of values that can be stored.
          C supports four basic (primitive) data types:
        </p>

        <Table
          headers={["Data Type", "Size (bytes)", "Format Specifier", "Range"]}
          rows={[
            [<span className="font-mono text-emerald-300">char</span>, "1", "%c", "-128 to 127"],
            [<span className="font-mono text-emerald-300">int</span>, "2 or 4", "%d", "-32,768 to 32,767 (if 2 bytes)"],
            [<span className="font-mono text-emerald-300">float</span>, "4", "%f", "±3.4e-38 to ±3.4e+38"],
            [<span className="font-mono text-emerald-300">double</span>, "8", "%lf", "±1.7e-308 to ±1.7e+308"],
            [<span className="font-mono text-emerald-300">void</span>, "0", "—", "No value (used with functions)"],
          ]}
        />

        <NoteBox type="tip" title="Sizeof Operator">
          You can check the actual size of any data type on your machine using{" "}
          <InlineCode>sizeof(type)</InlineCode>. Example: <InlineCode>printf("%lu", sizeof(int));</InlineCode>
        </NoteBox>

        <SubSection title="Example: Data Types in Action">
          <CodeBlock
            title="datatypes.c"
            code={`#include <stdio.h>

int main()
{
    char grade = 'A';
    int age = 20;
    float height = 5.9f;
    double pi = 3.14159265358979;

    printf("Grade  : %c\\n", grade);
    printf("Age    : %d\\n", age);
    printf("Height : %.2f\\n", height);
    printf("Pi     : %.10lf\\n", pi);

    printf("\\nSizes on this machine:\\n");
    printf("char   : %lu byte\\n",   sizeof(char));
    printf("int    : %lu bytes\\n",  sizeof(int));
    printf("float  : %lu bytes\\n",  sizeof(float));
    printf("double : %lu bytes\\n",  sizeof(double));

    return 0;
}`}
          />
        </SubSection>
      </Section>

      <Section title="2.4 Modifiers">
        <p className="mb-4 leading-relaxed text-slate-300">
          <strong className="text-white">Data type modifiers</strong> change the size or range of a base
          data type. They are applied to <InlineCode>int</InlineCode> and <InlineCode>char</InlineCode> (and
          <InlineCode>double</InlineCode> for <InlineCode>long</InlineCode>).
        </p>

        <SubSection title="Types of Modifiers">
          <Table
            headers={["Modifier", "Effect"]}
            rows={[
              [<span className="font-mono text-emerald-300">signed</span>, "Allows positive & negative values (default)"],
              [<span className="font-mono text-emerald-300">unsigned</span>, "Allows only positive values (doubles the positive range)"],
              [<span className="font-mono text-emerald-300">short</span>, "Reduces the size to half (or less)"],
              [<span className="font-mono text-emerald-300">long</span>, "Increases the size (usually double)"],
            ]}
          />
        </SubSection>

        <SubSection title="Sizes and Ranges with Modifiers">
          <Table
            headers={["Type", "Size", "Range"]}
            rows={[
              [<span className="font-mono">signed char</span>, "1", "-128 to 127"],
              [<span className="font-mono">unsigned char</span>, "1", "0 to 255"],
              [<span className="font-mono">short int</span>, "2", "-32,768 to 32,767"],
              [<span className="font-mono">unsigned short int</span>, "2", "0 to 65,535"],
              [<span className="font-mono">int</span>, "4", "-2,147,483,648 to 2,147,483,647"],
              [<span className="font-mono">unsigned int</span>, "4", "0 to 4,294,967,295"],
              [<span className="font-mono">long int</span>, "4 or 8", "Very large range"],
              [<span className="font-mono">long long int</span>, "8", "Very very large range"],
              [<span className="font-mono">long double</span>, "10 / 12 / 16", "Even larger than double"],
            ]}
          />
        </SubSection>

        <CodeBlock
          title="modifiers.c"
          code={`#include <stdio.h>

int main()
{
    unsigned int age = 25;       // cannot be negative
    long int population = 7800000000L;
    long double distance = 1.234567890123456789L;

    printf("Unsigned int size : %lu bytes\\n", sizeof(unsigned int));
    printf("Long int size     : %lu bytes\\n", sizeof(long int));
    printf("Long double size  : %lu bytes\\n", sizeof(long double));

    return 0;
}`}
        />
      </Section>

      <Section title="2.5 Variables">
        <p className="mb-4 leading-relaxed text-slate-300">
          A <strong className="text-white">variable</strong> is a named memory location whose value can
          change during program execution. Every variable must be <strong>declared</strong> before use.
        </p>

        <SubSection title="Variable Declaration Syntax">
          <div className="mb-4 rounded-lg border border-slate-700 bg-slate-900/60 p-4 text-center font-mono">
            <span className="text-violet-300">data_type</span>{" "}
            <span className="text-emerald-300">variable_name</span>{" "}
            <span className="text-amber-300">= value</span>;
          </div>
          <p className="mb-3 text-sm text-slate-400">Example:</p>
          <CodeBlock
            code={`int    count = 10;          // declaration + initialization
float  price;               // declaration only
price = 99.50;              // assignment
char   grade = 'A';
double total;`}
          />
        </SubSection>

        <NoteBox type="info" title="Declaration vs Definition">
          • <strong>Declaration:</strong> Tells the compiler about the variable's name and type.<br />
          • <strong>Definition:</strong> Allocates memory for the variable.<br />
          A definition is also a declaration, but a declaration may or may not be a definition.
        </NoteBox>
      </Section>

      <Section title="2.6 Constants">
        <p className="mb-4 leading-relaxed text-slate-300">
          A <strong className="text-white">constant</strong> is a fixed value that does not change during
          program execution. There are two ways to define constants in C:
        </p>

        <SubSection title="Method 1: Using #define (Preprocessor)">
          <CodeBlock
            code={`#define PI 3.14159
#define MAX 100
#define MSG "Hello"

int main() {
    float area = PI * 5 * 5;
    // PI cannot be changed later
    return 0;
}`}
          />
          <p className="mt-2 text-sm text-slate-400">
            No semicolon after <InlineCode>#define</InlineCode>. These are text-replaced before compilation.
          </p>
        </SubSection>

        <SubSection title="Method 2: Using const Keyword">
          <CodeBlock
            code={`const int MAX = 100;
const float PI = 3.14159f;
const char *name = "Ravi";

// MAX = 200;   // ERROR: assignment of read-only variable`}
          />
        </SubSection>

        <SubSection title="Types of Constants">
          <Table
            headers={["Type", "Example"]}
            rows={[
              ["Integer Constant", <span className="font-mono">10, -5, 0, 077 (octal), 0xFF (hex)</span>],
              ["Floating Constant", <span className="font-mono">3.14, -0.001, 2.5e-3</span>],
              ["Character Constant", <span className="font-mono">'A', '9', '\n'</span>],
              ["String Constant", <span className="font-mono">"Hello", "C Programming"</span>],
            ]}
          />
        </SubSection>
      </Section>

      {/* Summary */}
      <div className="mt-10 rounded-xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-6">
        <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-white">
          <span>📝</span> Chapter Summary
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• <strong className="text-white">Identifiers:</strong> Names for variables/functions — start with letter/_, no keywords, case-sensitive.</li>
          <li>• <strong className="text-white">Keywords:</strong> 32 reserved words in C, always lowercase.</li>
          <li>• <strong className="text-white">Data Types:</strong> char, int, float, double, void.</li>
          <li>• <strong className="text-white">Modifiers:</strong> signed, unsigned, short, long — change size/range.</li>
          <li>• <strong className="text-white">Variables:</strong> Named memory locations; declared as <InlineCode>type name;</InlineCode></li>
          <li>• <strong className="text-white">Constants:</strong> Fixed values using <InlineCode>#define</InlineCode> or <InlineCode>const</InlineCode>.</li>
        </ul>
      </div>

      <div className="mt-6 rounded-xl border border-violet-500/30 bg-violet-500/5 p-5">
        <h3 className="mb-3 flex items-center gap-2 font-semibold text-violet-300">
          <span>🧠</span> Quick Check
        </h3>
        <div className="space-y-4 text-sm text-slate-300">
          <div className="rounded-lg border border-slate-700 bg-slate-900/40 p-3">
            <p className="mb-1 font-semibold text-white">Q1. Is <InlineCode>_total</InlineCode> a valid identifier?</p>
            <details className="text-slate-400">
              <summary className="cursor-pointer text-emerald-300 hover:text-emerald-200">Show answer</summary>
              <p className="mt-1">Yes — identifiers can start with a letter or underscore.</p>
            </details>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-900/40 p-3">
            <p className="mb-1 font-semibold text-white">Q2. What is the size of <InlineCode>int</InlineCode> on most modern systems?</p>
            <details className="text-slate-400">
              <summary className="cursor-pointer text-emerald-300 hover:text-emerald-200">Show answer</summary>
              <p className="mt-1">4 bytes (32 bits).</p>
            </details>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-900/40 p-3">
            <p className="mb-1 font-semibold text-white">Q3. How do you declare a constant integer in C?</p>
            <details className="text-slate-400">
              <summary className="cursor-pointer text-emerald-300 hover:text-emerald-200">Show answer</summary>
              <p className="mt-1">Either <InlineCode>const int N = 100;</InlineCode> or <InlineCode>#define N 100</InlineCode>.</p>
            </details>
          </div>
        </div>
      </div>
    </div>
  );
}
