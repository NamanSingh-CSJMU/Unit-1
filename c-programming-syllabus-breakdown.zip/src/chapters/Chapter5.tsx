import CodeBlock from "../components/CodeBlock";
import { Section, SubSection, NoteBox, InlineCode, Table } from "../components/UI";

export default function Chapter5() {
  return (
    <div className="space-y-2">
      <div className="mb-8 border-b border-slate-800 pb-6">
        <div className="mb-2 flex items-center gap-2">
          <span className="rounded-full bg-rose-500/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-rose-300">
            Chapter 5
          </span>
          <span className="text-xs text-slate-500">~ 18 min read</span>
        </div>
        <h1 className="mb-3 bg-gradient-to-r from-rose-300 via-pink-300 to-amber-300 bg-clip-text text-4xl font-extrabold text-transparent md:text-5xl">
          Conditional Statements &amp; Switch
        </h1>
        <p className="text-lg text-slate-400">
          Control the flow of your program using if, if-else, nested if, else-if ladder, and the switch statement.
        </p>
      </div>

      <div className="rounded-xl border border-rose-500/30 bg-rose-500/5 p-5">
        <h3 className="mb-3 flex items-center gap-2 font-semibold text-rose-300">
          <span>🎯</span> Learning Objectives
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• Understand decision-making in C</li>
          <li>• Use if, if-else, and else-if ladder</li>
          <li>• Handle nested conditions correctly</li>
          <li>• Use switch for multi-way branching</li>
          <li>• Know when to use which statement</li>
        </ul>
      </div>

      <Section title="5.1 What are Control Structures?">
        <p className="mb-4 leading-relaxed text-slate-300">
          A <strong className="text-white">control structure</strong> (also called a <em>selection</em> or
          <em>decision-making</em> structure) determines the order in which statements are executed. By
          default, C executes statements <strong>sequentially</strong>. Control structures let us:
        </p>
        <ul className="ml-6 list-disc space-y-1 text-slate-300">
          <li><strong className="text-white">Skip</strong> some statements based on a condition.</li>
          <li><strong className="text-white">Choose</strong> one of several paths.</li>
          <li><strong className="text-white">Repeat</strong> statements (loops — covered in Chapter 6).</li>
        </ul>
        <p className="mt-4 text-slate-300">
          The main conditional statements in C are: <InlineCode>if</InlineCode>, <InlineCode>if-else</InlineCode>,
          <InlineCode>else-if ladder</InlineCode>, <InlineCode>nested if</InlineCode>, and{" "}
          <InlineCode>switch</InlineCode>.
        </p>
      </Section>

      <Section title="5.2 The if Statement">
        <p className="mb-3 leading-relaxed text-slate-300">
          The simplest decision-making statement. Executes a block of code <strong>only if</strong> a condition is true (non-zero).
        </p>
        <div className="mb-3 rounded-lg border border-slate-700 bg-slate-900/60 p-4 font-mono text-sm">
          <span className="text-violet-300">if</span> (<span className="text-amber-300">condition</span>) {"{"}<br />
          &nbsp;&nbsp;<span className="text-slate-400">/* statements executed only if condition is true */</span><br />
          {"}"}
        </div>
        <CodeBlock
          title="simple_if.c"
          code={`#include <stdio.h>

int main()
{
    int marks;
    printf("Enter marks: ");
    scanf("%d", &marks);

    if (marks >= 40) {
        printf("You PASSED!\\n");
    }

    printf("End of program.\\n");
    return 0;
}`}
        />
        <NoteBox type="tip" title="When is a condition true?">
          In C, any <strong>non-zero</strong> value is considered <em>true</em>, and <strong>zero</strong> is
          <em>false</em>. So <InlineCode>if (1)</InlineCode> always runs, while <InlineCode>if (0)</InlineCode> never runs.
        </NoteBox>
      </Section>

      <Section title="5.3 The if-else Statement">
        <p className="mb-3 leading-relaxed text-slate-300">
          Executes one block if the condition is true, <strong>or another</strong> block if it is false.
        </p>
        <CodeBlock
          title="if_else.c"
          code={`#include <stdio.h>

int main()
{
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    if (num % 2 == 0) {
        printf("%d is EVEN\\n", num);
    } else {
        printf("%d is ODD\\n", num);
    }

    return 0;
}`}
        />
      </Section>

      <Section title="5.4 The else-if Ladder">
        <p className="mb-3 leading-relaxed text-slate-300">
          Used when you need to test <strong>multiple conditions in sequence</strong>. The first true condition's
          block executes, and the rest are skipped.
        </p>
        <CodeBlock
          title="elseif_grade.c"
          code={`#include <stdio.h>

int main()
{
    int marks;
    printf("Enter marks: ");
    scanf("%d", &marks);

    if (marks >= 90) {
        printf("Grade: A+\\n");
    } else if (marks >= 75) {
        printf("Grade: A\\n");
    } else if (marks >= 60) {
        printf("Grade: B\\n");
    } else if (marks >= 40) {
        printf("Grade: C\\n");
    } else {
        printf("Grade: FAIL\\n");
    }

    return 0;
}`}
        />
        <NoteBox type="info" title="Efficiency">
          Once a true condition is found, no further <InlineCode>else if</InlineCode> blocks are tested.
          So put the <strong>most likely</strong> or <strong>cheapest</strong> condition first for efficiency.
        </NoteBox>
      </Section>

      <Section title="5.5 Nested if Statements">
        <p className="mb-3 leading-relaxed text-slate-300">
          An <InlineCode>if</InlineCode> statement inside another <InlineCode>if</InlineCode> statement.
          Useful when a decision depends on <strong>multiple conditions together</strong>.
        </p>
        <CodeBlock
          title="nested_if.c"
          code={`#include <stdio.h>

int main()
{
    int age, hasLicense;
    printf("Enter age: ");
    scanf("%d", &age);
    printf("Has license (1=yes, 0=no): ");
    scanf("%d", &hasLicense);

    if (age >= 18) {
        if (hasLicense == 1) {
            printf("You can drive.\\n");
        } else {
            printf("Apply for a license first.\\n");
        }
    } else {
        printf("You are too young to drive.\\n");
    }

    return 0;
}`}
        />
        <NoteBox type="tip">
          You can combine conditions using <InlineCode>&amp;&amp;</InlineCode> and <InlineCode>||</InlineCode>{" "}
          instead of nesting — it's often cleaner:
          <br />
          <InlineCode>if (age &gt;= 18 &amp;&amp; hasLicense)</InlineCode>
        </NoteBox>
      </Section>

      <Section title="5.6 The switch Statement">
        <p className="mb-3 leading-relaxed text-slate-300">
          The <InlineCode>switch</InlineCode> statement provides a clean way to choose among
          <strong> multiple fixed values</strong> of a single variable. It is an alternative to a long
          <InlineCode>else-if</InlineCode> ladder.
        </p>
        <div className="mb-3 rounded-lg border border-slate-700 bg-slate-900/60 p-4 font-mono text-sm">
          <span className="text-violet-300">switch</span> (<span className="text-amber-300">expression</span>) {"{"}<br />
          &nbsp;&nbsp;<span className="text-violet-300">case</span> <span className="text-amber-300">value1</span>: ... ; <span className="text-emerald-300">break</span>;<br />
          &nbsp;&nbsp;<span className="text-violet-300">case</span> <span className="text-amber-300">value2</span>: ... ; <span className="text-emerald-300">break</span>;<br />
          &nbsp;&nbsp;<span className="text-violet-300">default</span>: ... ;<br />
          {"}"}
        </div>

        <CodeBlock
          title="switch_day.c"
          code={`#include <stdio.h>

int main()
{
    int day;
    printf("Enter day number (1-7): ");
    scanf("%d", &day);

    switch (day) {
        case 1: printf("Monday\\n");    break;
        case 2: printf("Tuesday\\n");   break;
        case 3: printf("Wednesday\\n"); break;
        case 4: printf("Thursday\\n");  break;
        case 5: printf("Friday\\n");    break;
        case 6: printf("Saturday\\n");  break;
        case 7: printf("Sunday\\n");    break;
        default: printf("Invalid day!\\n");
    }

    return 0;
}`}
        />

        <SubSection title="Rules for switch">
          <ul className="ml-6 list-disc space-y-1.5 text-slate-300">
            <li>The expression must evaluate to an <strong>integer</strong> or <strong>character</strong> (not float/double).</li>
            <li>Case labels must be <strong>constant expressions</strong> (no variables).</li>
            <li>Case labels must be <strong>unique</strong>.</li>
            <li><InlineCode>break</InlineCode> is optional but usually needed — otherwise <strong>fall-through</strong> occurs.</li>
            <li><InlineCode>default</InlineCode> is optional and can be placed anywhere, but conventionally at the end.</li>
          </ul>
        </SubSection>

        <SubSection title="Fall-Through Example">
          <p className="mb-2 text-sm text-slate-300">
            If you forget <InlineCode>break</InlineCode>, execution continues into the next case. This can be
            useful sometimes, but usually it's a bug.
          </p>
          <CodeBlock
            code={`int x = 2;
switch (x) {
    case 1: printf("One\\n");     // skipped
    case 2: printf("Two\\n");     // runs → prints "Two"
    case 3: printf("Three\\n");   // ALSO runs! (no break)
    default: printf("Other\\n");  // ALSO runs!
}`}
          />
          <p className="mt-2 text-sm text-slate-400">Output: Two, Three, Other — all printed!</p>
        </SubSection>
      </Section>

      <Section title="5.7 if vs switch — When to Use Which?">
        <Table
          headers={["Feature", "if / if-else", "switch"]}
          rows={[
            ["Test type", "Any relational / logical condition", "Only equality with constants"],
            ["Data types", "Any (int, float, pointer, etc.)", "Only int or char"],
            ["Ranges", "Easy (e.g., x &gt; 10)", "Not supported — must list each value"],
            ["Speed", "Slower for many conditions", "Usually faster (jump table)"],
            ["Readability", "Flexible but can be verbose", "Clean for many fixed values"],
            ["Use when…", "Conditions are complex or range-based", "Checking one variable against fixed values"],
          ]}
        />
      </Section>

      {/* Summary */}
      <div className="mt-10 rounded-xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-6">
        <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-white">
          <span>📝</span> Chapter Summary
        </h3>
        <ul className="space-y-2 text-sm text-slate-300">
          <li>• <strong className="text-white">if:</strong> Simple one-way decision.</li>
          <li>• <strong className="text-white">if-else:</strong> Two-way decision.</li>
          <li>• <strong className="text-white">else-if ladder:</strong> Multi-way decision with range/complex conditions.</li>
          <li>• <strong className="text-white">Nested if:</strong> if inside if for compound conditions.</li>
          <li>• <strong className="text-white">switch:</strong> Clean multi-way branch for fixed values; needs <InlineCode>break</InlineCode>.</li>
          <li>• Non-zero = true, zero = false in C.</li>
        </ul>
      </div>
    </div>
  );
}
