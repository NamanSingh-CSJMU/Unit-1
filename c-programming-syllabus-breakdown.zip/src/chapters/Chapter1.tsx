import { useState } from "react";
import CodeBlock from "../components/CodeBlock";
import Quiz from "../components/Quiz";
import {
  Section,
  SubSection,
  NoteBox,
  IC,
  Table,
  CardGrid,
  DefList,
  Timeline,
  Collapse,
} from "../components/UI";

/* --- backslash-safe helpers (never type literal backslashes in strings) --- */
const BS = String.fromCharCode(92); // one backslash
const NL = BS + "n"; // the two characters  \n
const TAB = BS + "t";
const NUL = BS + "0";
const DQ = String.fromCharCode(34); // double quote
const SQ = String.fromCharCode(39); // single quote

/* ---------- Annotated Hello-World line explorer ---------- */
const lines = [
  {
    code: "#include <stdio.h>",
    title: "Preprocessor directive (Link section)",
    desc: "Tells the preprocessor to paste the contents of the header file stdio.h (Standard Input Output) into our program before compiling. This file contains the declarations of printf() and scanf(). It always starts with # and has NO semicolon.",
    tag: "Header",
    color: "text-pink-400",
  },
  {
    code: "int main()",
    title: "main() function header",
    desc: "Every C program starts executing from main(). int is the return type - it tells the OS whether the program finished successfully. The empty () means main takes no parameters. Exactly one main must exist.",
    tag: "Entry point",
    color: "text-violet-400",
  },
  {
    code: "{",
    title: "Opening brace (start of function body)",
    desc: "Begins the block that contains all statements of main(). Every { must have a matching }. Everything between them belongs to the function.",
    tag: "Block",
    color: "text-slate-300",
  },
  {
    code: `    printf("Hello, World!${NL}");`,
    title: "Executable statement",
    desc: `Calls the library function printf() to print text on the screen. The text inside double quotes is a string literal. ${NL} is an escape sequence that moves the cursor to the next line. The semicolon ; terminates every C statement.`,
    tag: "Statement",
    color: "text-emerald-300",
  },
  {
    code: "    return 0;",
    title: "Return statement",
    desc: "Sends the value 0 back to the operating system. By convention 0 means the program completed successfully; any non-zero value signals an error. Returning from main() ends the program.",
    tag: "Exit",
    color: "text-amber-300",
  },
  {
    code: "}",
    title: "Closing brace (end of function body)",
    desc: "Ends main(). The compiler now knows the function is complete. Forgetting this brace is one of the most common beginner errors.",
    tag: "Block",
    color: "text-slate-300",
  },
];

function LineAnatomy() {
  const [active, setActive] = useState(0);
  const cur = lines[active];
  return (
    <div className="my-4 min-w-0">
      <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
        Tap a line to understand it
      </div>
      <div className="overflow-hidden rounded-xl border border-slate-700 bg-slate-950">
        {lines.map((l, i) => (
          <button
            key={i}
            onClick={() => setActive(i)}
            className={`flex w-full items-center gap-2.5 border-b border-slate-800 px-3 py-2.5 text-left font-mono text-[12.5px] transition last:border-b-0 sm:text-[13.5px] ${
              i === active
                ? "bg-slate-800/80 text-white"
                : "bg-transparent text-slate-400 hover:bg-slate-900"
            }`}
          >
            <span className="w-4 shrink-0 select-none text-right text-slate-600">
              {i + 1}
            </span>
            <span className={`min-w-0 break-all ${l.color}`}>{l.code}</span>
          </button>
        ))}
      </div>
      <div className="mt-3 rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3.5 sm:p-4">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-300">
            {cur.tag}
          </span>
          <span className="text-sm font-bold text-white sm:text-base">
            {cur.title}
          </span>
        </div>
        <p className="text-[13.5px] leading-relaxed text-slate-300 sm:text-sm">
          {cur.desc}
        </p>
      </div>
    </div>
  );
}

/* ---------- Compilation pipeline ---------- */
const stages = [
  {
    n: "1",
    t: "Source Code",
    sub: "hello.c",
    d: "You write the program in an editor (VS Code, Turbo C, vi) and save it with the .c extension. This is plain text - the computer cannot run it yet.",
    c: "from-slate-500 to-slate-700",
  },
  {
    n: "2",
    t: "Preprocessor",
    sub: "cpp hello.c",
    d: "Handles every line starting with #. It expands #include (pastes header file contents) and #define (replaces macros). Output: hello.i",
    c: "from-pink-500 to-rose-600",
  },
  {
    n: "3",
    t: "Compiler",
    sub: "gcc -S",
    d: "Translates the expanded C source into assembly language for your CPU and reports all syntax errors here. Output: hello.s",
    c: "from-orange-500 to-amber-600",
  },
  {
    n: "4",
    t: "Assembler",
    sub: "as hello.s",
    d: "Converts assembly into machine code (object code). Output: hello.o / hello.obj - binary, but still not executable on its own.",
    c: "from-amber-500 to-yellow-600",
  },
  {
    n: "5",
    t: "Linker",
    sub: "ld",
    d: "Combines your object code with library object code (for example the real code of printf) and fixes all addresses. Output: a.out / hello.exe",
    c: "from-emerald-500 to-teal-600",
  },
  {
    n: "6",
    t: "Loader",
    sub: "run",
    d: "When you run the program, the loader copies the executable into RAM, allocates memory for variables and hands control to main().",
    c: "from-cyan-500 to-blue-600",
  },
];

function Pipeline() {
  return (
    <div className="my-5 min-w-0">
      {stages.map((s, i) => (
        <div key={s.n} className="flex gap-3">
          <div className="flex flex-col items-center">
            <div
              className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${s.c} text-sm font-bold text-white shadow-lg`}
            >
              {s.n}
            </div>
            {i < stages.length - 1 && (
              <div className="my-1 w-0.5 flex-1 bg-gradient-to-b from-slate-600 to-slate-700"></div>
            )}
          </div>
          <div className="min-w-0 flex-1 pb-4">
            <div className="flex flex-wrap items-baseline gap-x-2">
              <span className="font-bold text-white">{s.t}</span>
              <span className="break-all font-mono text-[11px] text-slate-500">
                {s.sub}
              </span>
            </div>
            <p className="mt-1 text-[13.5px] leading-relaxed text-slate-400 sm:text-sm">
              {s.d}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

const specialChars = [
  "~", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")",
  "_", "-", "+", "=", "{", "}", "[", "]", "|", BS, ":", ";",
  DQ, SQ, "<", ">", ",", ".", "?", "/",
];

/* ================= CHAPTER 1 ================= */
export default function Chapter1() {
  return (
    <div className="min-w-0">
      {/* ---------- HERO ---------- */}
      <div className="mb-8 border-b border-slate-800 pb-6">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-emerald-300">
            Chapter 1
          </span>
          <span className="rounded-full bg-violet-500/20 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-violet-300">
            In-Depth
          </span>
          <span className="text-[11px] text-slate-500">about 40 min read</span>
        </div>
        <h1 className="mb-3 break-words bg-gradient-to-r from-emerald-300 via-cyan-300 to-violet-300 bg-clip-text text-[1.75rem] font-extrabold leading-tight text-transparent sm:text-4xl md:text-5xl">
          Introduction to C Programming
        </h1>
        <p className="text-[15px] leading-relaxed text-slate-400 sm:text-lg">
          History of C, Structure of a C program, C Conventions and the C
          Character Set - explained from absolute zero, step by step.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {[
            "History of C",
            "Structure of a Program",
            "Compilation Process",
            "C Conventions",
            "Character Set",
            "Tokens",
          ].map((t) => (
            <span
              key={t}
              className="rounded-lg border border-slate-700 bg-slate-900/60 px-2.5 py-1 text-[11px] font-medium text-slate-400"
            >
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* ---------- OBJECTIVES ---------- */}
      <div className="mb-8 rounded-2xl border border-violet-500/30 bg-violet-500/5 p-4 sm:p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-violet-300 sm:text-base">
          <span>🎯</span> What you will be able to do after this chapter
        </h3>
        <ul className="grid gap-2 text-[13.5px] text-slate-300 sm:grid-cols-2 sm:text-sm">
          {[
            "Explain how C was born and why it matters",
            "Name the 6 sections of a C program in order",
            "Write, compile and run your first C program",
            "Describe the 6 stages of the build process",
            "Follow professional C naming conventions",
            "List the C character set and count its symbols",
            "Identify tokens inside a line of code",
            "Recognise and fix the 4 types of errors",
          ].map((o) => (
            <li key={o} className="flex items-start gap-2">
              <span className="mt-0.5 shrink-0 text-violet-400">✓</span>
              <span className="min-w-0">{o}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* ================= 1.1 ================= */}
      <Section title="1.1 Before C - Programs and Programming Languages">
        <p className="mb-4 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          A <strong className="text-white">computer</strong> only understands{" "}
          <strong className="text-white">machine language</strong> - pure binary
          0s and 1s. A <strong className="text-white">program</strong> is a set
          of instructions that tells the computer what to do step by step, and a{" "}
          <strong className="text-white">programming language</strong> is the
          vocabulary plus grammar rules used to write those instructions.
        </p>

        <SubSection title="Levels of Programming Languages">
          <div className="grid gap-3 sm:grid-cols-3">
            {[
              {
                t: "Low Level",
                icon: "🔩",
                items: "Machine Language, Assembly",
                d: "Written in binary or mnemonics. Extremely fast but almost unreadable for humans. Machine dependent.",
                tone: "border-red-500/30 bg-red-500/5",
              },
              {
                t: "Middle Level",
                icon: "⚙️",
                items: "C, C++",
                d: "Combines the power of assembly with the readability of high-level languages. This is exactly where C sits.",
                tone: "border-emerald-500/40 bg-emerald-500/5",
              },
              {
                t: "High Level",
                icon: "🚀",
                items: "Python, Java, C#",
                d: "English-like, easy to read, machine independent - but slower and further from the hardware.",
                tone: "border-sky-500/30 bg-sky-500/5",
              },
            ].map((l) => (
              <div key={l.t} className={`min-w-0 rounded-xl border p-3.5 ${l.tone}`}>
                <div className="mb-1 flex items-center gap-2 font-bold text-white">
                  <span>{l.icon}</span>
                  <span>{l.t}</span>
                </div>
                <div className="mb-2 font-mono text-[11px] text-emerald-300">
                  {l.items}
                </div>
                <p className="text-[13px] leading-relaxed text-slate-400">{l.d}</p>
              </div>
            ))}
          </div>
        </SubSection>

        <SubSection title="Language Translators">
          <Table
            headers={["Translator", "What it does", "Input - Output"]}
            rows={[
              [
                <strong key="a" className="text-white">Assembler</strong>,
                "Converts assembly language to machine code (one-to-one mapping)",
                <span key="b" className="font-mono text-[11px]">.asm - .obj</span>,
              ],
              [
                <strong key="c" className="text-white">Compiler</strong>,
                "Translates the WHOLE high-level program at once and reports all errors together. Faster execution.",
                <span key="d" className="font-mono text-[11px]">.c - .exe</span>,
              ],
              [
                <strong key="e" className="text-white">Interpreter</strong>,
                "Translates and executes one line at a time, stopping at the first error. Easier to debug, slower to run.",
                <span key="f" className="font-mono text-[11px]">line - run</span>,
              ],
            ]}
            caption="C is a compiled language - that is why we need gcc or Turbo C."
          />
        </SubSection>
      </Section>

      {/* ================= 1.2 HISTORY ================= */}
      <Section title="1.2 History of C (Complete Evolution)">
        <p className="mb-4 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          The <strong className="text-white">C programming language</strong> was
          developed by <strong className="text-emerald-300">Dennis M. Ritchie</strong>{" "}
          between 1969 and 1973, with the first usable version in{" "}
          <strong className="text-white">1972</strong>, at the{" "}
          <em className="text-slate-400">Bell Telephone Laboratories</em> in
          Murray Hill, New Jersey, USA. He built it mainly to{" "}
          <strong className="text-white">rewrite the UNIX operating system</strong>{" "}
          on a DEC PDP-11 so the OS would not have to be rewritten in assembly
          for every new computer.
        </p>

        <NoteBox type="exam" title="Very Important for Exams">
          C was developed by <strong>Dennis Ritchie</strong> in{" "}
          <strong>1972</strong> at <strong>Bell Labs</strong>, mainly to write
          the <strong>UNIX operating system</strong>. Its direct ancestor is the{" "}
          <strong>B</strong> language by Ken Thompson, which came from{" "}
          <strong>BCPL</strong> by Martin Richards.
        </NoteBox>

        <SubSection title="The Family Tree of C">
          <Timeline
            items={[
              {
                year: "1960",
                title: "ALGOL 60",
                body: "Built by an international committee. The first language with a truly formal, structured grammar, but too abstract for commercial work. C inherited its block-structured idea.",
              },
              {
                year: "1963",
                title: "CPL (Combined Programming Language)",
                body: "Created by Cambridge and London universities. More practical than ALGOL but still large, slow and hard to implement.",
              },
              {
                year: "1967",
                title: "BCPL (Basic CPL)",
                body: "Martin Richards stripped CPL down to the essentials - a tiny language with no data types at all, ideal for writing compilers and system software.",
              },
              {
                year: "1970",
                title: "B Language",
                body: "Ken Thompson, a colleague of Ritchie, rewrote BCPL for the UNIX project on a PDP-7. B was also typeless and word-oriented, which made it inefficient on the newer byte-addressed PDP-11.",
              },
              {
                year: "1972",
                title: "C Language",
                hot: true,
                body: "Dennis Ritchie added data types (char, int, float), arrays, structures and pointers to B, producing a fast, small, portable language. In 1973 UNIX itself was rewritten in C, proving a high-level language could build an operating system.",
              },
              {
                year: "1978",
                title: "K&R C - The C Bible",
                body: "Brian Kernighan and Dennis Ritchie published the book 'The C Programming Language'. This book, not a committee, became the de-facto standard and is still the best selling programming book ever.",
              },
              {
                year: "1983-1989",
                title: "ANSI C (C89 / C90)",
                body: "Because every compiler maker added its own extras, ANSI formed committee X3J11 in 1983 to standardise C. Approved in 1989 as ANSI C or C89; ISO adopted it in 1990 as C90. This is what most textbooks teach.",
              },
              {
                year: "1999",
                title: "C99",
                body: "Added // single-line comments, the long long type, declarations anywhere inside a block, inline functions and the stdbool.h boolean type.",
              },
              {
                year: "2011",
                title: "C11",
                body: "Added multi-threading support (thread.h), anonymous structures, bounds-checked functions, and made variable-length arrays optional.",
              },
              {
                year: "2018 / 2024",
                title: "C17 and C23",
                body: "C17 was a bug-fix release. C23, the newest standard, brings a true bool type, constexpr, binary literals like 0b1010 and cleaner headers.",
              },
            ]}
          />
        </SubSection>

        <div className="my-5 overflow-x-auto rounded-xl border border-slate-700 bg-slate-950 p-4">
          <div className="mb-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-500">
            Evolution chain - memorise this order
          </div>
          <div className="flex min-w-max items-center gap-2">
            {["ALGOL", "CPL", "BCPL", "B", "C"].map((s, i, arr) => (
              <div key={s} className="flex items-center gap-2">
                <span
                  className={`rounded-lg border px-3 py-2 font-mono text-sm font-bold ${
                    s === "C"
                      ? "border-emerald-400 bg-emerald-500/20 text-emerald-300 shadow-lg shadow-emerald-500/20"
                      : "border-slate-700 bg-slate-900 text-slate-400"
                  }`}
                >
                  {s}
                </span>
                {i < arr.length - 1 && <span className="text-slate-600">→</span>}
              </div>
            ))}
          </div>
        </div>

        <NoteBox type="info" title="Why is it named C?">
          Simply because it succeeded <strong>B</strong>, which succeeded{" "}
          <strong>BCPL</strong>. There had been a brief experimental language
          called D before C, so Ritchie skipped ahead and used the next free
          letter - C.
        </NoteBox>
      </Section>

      {/* ================= 1.3 FEATURES ================= */}
      <Section title="1.3 Features (Characteristics) of C">
        <p className="mb-3 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          These are the classic reasons C is still taught first and still powers
          operating systems, databases and embedded devices today.
        </p>
        <CardGrid
          cols={2}
          items={[
            {
              icon: "🧩",
              t: "1. Simple and Clean Syntax",
              d: <>Only <IC>32 keywords</IC> and a small set of building blocks - functions, loops and decisions. English-like and easy to learn.</>,
            },
            {
              icon: "⚡",
              t: "2. Fast and Efficient",
              d: "Compiled straight to machine code with almost no runtime overhead. C programs are usually as fast as hand written assembly.",
            },
            {
              icon: "🎚️",
              t: "3. Middle-Level Language",
              d: <>Supports high-level features (functions, arrays, structures) <em>and</em> low-level bit and byte manipulation through pointers and bitwise operators.</>,
            },
            {
              icon: "📦",
              t: "4. Structured Language",
              d: "Code is broken into functions and blocks { }, making programs modular, readable and easy to debug. Supports top-down design.",
            },
            {
              icon: "🌍",
              t: "5. Portable",
              d: <>A program written on one machine runs on another with little or no change - just recompile. This is why UNIX spread everywhere: write once, compile anywhere.</>,
            },
            {
              icon: "📚",
              t: "6. Rich Library",
              d: <>Hundreds of ready-made functions in headers such as <IC>stdio.h</IC>, <IC>math.h</IC>, <IC>string.h</IC> and <IC>stdlib.h</IC>.</>,
            },
            {
              icon: "👉",
              t: "7. Pointer and Memory Power",
              d: <>Direct access to memory addresses using <IC>&amp;</IC> and <IC>*</IC>, plus dynamic allocation with <IC>malloc</IC> - the heart of data structures.</>,
            },
            {
              icon: "🔁",
              t: "8. Extensible",
              d: "You can create your own functions and whole libraries and reuse them anywhere. C also links easily with assembly code.",
            },
            {
              icon: "🧮",
              t: "9. Rich Set of Operators",
              d: "Arithmetic, relational, logical, bitwise, assignment, increment and ternary operators let you write very compact expressions.",
            },
            {
              icon: "🏗️",
              t: "10. Foundation Language",
              d: "C++, Java, C#, JavaScript, Python, Go, Rust and PHP all borrowed syntax from C. Learn C once and you can read them all.",
            },
          ]}
        />

        <NoteBox type="warn" title="Honest Limitations of C">
          C has <strong>no runtime checking</strong> (an out-of-range array index
          silently corrupts memory), <strong>no garbage collection</strong> (you
          must free what you malloc), <strong>no object oriented programming</strong>{" "}
          (no classes or inheritance) and <strong>no exception handling</strong>{" "}
          (no try/catch). These are exactly what C++ and Java added later.
        </NoteBox>

        <SubSection title="Where is C actually used today?">
          <div className="flex flex-wrap gap-2">
            {[
              "Operating systems (UNIX, Linux, Windows kernel)",
              "Embedded systems and IoT",
              "Device drivers",
              "Databases (MySQL, PostgreSQL)",
              "Compilers and interpreters",
              "The Python interpreter (CPython)",
              "Robotics and automotive",
              "Game engines and graphics",
            ].map((u) => (
              <span
                key={u}
                className="rounded-lg border border-slate-700 bg-slate-900/60 px-2.5 py-1.5 text-[12px] text-slate-300"
              >
                {u}
              </span>
            ))}
          </div>
        </SubSection>
      </Section>

      {/* ================= 1.4 COMPILATION ================= */}
      <Section title="1.4 How a C Program Actually Runs (Build Process)">
        <p className="mb-4 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          This is the single most asked exam question from Unit 1. A plain{" "}
          <IC>.c</IC> text file passes through{" "}
          <strong className="text-white">six stages</strong> before you see
          output on the screen:
        </p>

        <Pipeline />

        <div className="my-4 grid gap-3 lg:grid-cols-2">
          <div className="rounded-xl border border-slate-700 bg-slate-900/60 p-4">
            <h4 className="mb-2 text-sm font-bold text-emerald-300">
              🖥️ Using GCC (Linux, Mac, Code::Blocks)
            </h4>
            <CodeBlock
              title="terminal"
              code={`gcc hello.c -o hello    # compile + link
./hello                  # run the program

# to see each intermediate stage:
gcc -E hello.c > hello.i  # 1 preprocessed
gcc -S hello.i            # 2 assembly
gcc -c hello.s            # 3 object code
gcc hello.o -o hello      # 4 link to executable`}
            />
          </div>
          <div className="rounded-xl border border-slate-700 bg-slate-900/60 p-4">
            <h4 className="mb-2 text-sm font-bold text-emerald-300">
              🪟 Using Turbo C (classic Windows lab setup)
            </h4>
            <ol className="ml-5 list-decimal space-y-1.5 text-[13.5px] text-slate-300">
              <li>Open Turbo C, then <strong>File → New</strong></li>
              <li>Type your program</li>
              <li><strong>File → Save as</strong> <IC>hello.c</IC></li>
              <li>
                <strong>Compile → Compile</strong> (Alt + F9) and check for errors
              </li>
              <li><strong>Run → Run</strong> (Ctrl + F9)</li>
              <li>
                See the output with <strong>Window → User Screen</strong> (Alt + F5)
              </li>
            </ol>
          </div>
        </div>

        <Table
          headers={["Stage", "Input file", "Output file", "Tool used"]}
          rows={[
            ["Preprocessing", <IC key="1">hello.c</IC>, <IC key="2">hello.i</IC>, "Preprocessor (cpp)"],
            ["Compilation", <IC key="3">hello.i</IC>, <IC key="4">hello.s</IC>, "C compiler (gcc)"],
            ["Assembly", <IC key="5">hello.s</IC>, <IC key="6">hello.o</IC>, "Assembler (as)"],
            ["Linking", <IC key="7">hello.o + libraries</IC>, <IC key="8">hello.exe</IC>, "Linker (ld)"],
            ["Loading", <IC key="9">hello.exe</IC>, "Process in RAM", "Loader (OS)"],
          ]}
        />
      </Section>

      {/* ================= 1.5 STRUCTURE ================= */}
      <Section title="1.5 Structure of a C Program">
        <p className="mb-4 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          Every complete C program is built from up to{" "}
          <strong className="text-white">six sections</strong>. Only the{" "}
          <IC>main()</IC> function section is compulsory - the rest are optional,
          but every professional program uses them all.
        </p>

        <div className="my-5 grid gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
          {[
            { n: "1", t: "Documentation", s: "comments", d: "Name, author, date, purpose", c: "from-slate-500 to-slate-700" },
            { n: "2", t: "Link", s: "#include", d: "Connect header and library files", c: "from-cyan-400 to-cyan-600" },
            { n: "3", t: "Definition", s: "#define", d: "Symbolic constants and macros", c: "from-sky-400 to-sky-600" },
            { n: "4", t: "Global Declaration", s: "vars, prototypes", d: "Usable in every function", c: "from-violet-400 to-violet-600" },
            { n: "5", t: "main()", s: "compulsory", d: "Declaration part + executable part", c: "from-fuchsia-500 to-pink-600" },
            { n: "6", t: "Sub Programs", s: "user functions", d: "Called from main or each other", c: "from-amber-400 to-orange-600" },
          ].map((p) => (
            <div
              key={p.n}
              className="min-w-0 rounded-xl border border-slate-700 bg-slate-900/50 p-3"
            >
              <div
                className={`mb-2 flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br ${p.c} text-sm font-bold text-white`}
              >
                {p.n}
              </div>
              <div className="text-[13px] font-bold text-white">{p.t}</div>
              <div className="mb-1 font-mono text-[10.5px] text-emerald-300">
                {p.s}
              </div>
              <div className="text-[12px] leading-snug text-slate-400">{p.d}</div>
            </div>
          ))}
        </div>

        <SubSection title="A program showing ALL six sections">
          <CodeBlock
            title="structure_demo.c"
            output={`Area of circle = 78.54
Square of 5 = 25`}
            code={`/* =============================================
   1. DOCUMENTATION SECTION
   Program : structure_demo.c
   Author  : Student Name
   Purpose : Shows all 6 sections of a C program
   ============================================= */

/* 2. LINK SECTION - connect the standard libraries */
#include <stdio.h>

/* 3. DEFINITION SECTION - symbolic constants */
#define PI 3.14159
#define MAX 100

/* 4. GLOBAL DECLARATION SECTION */
float area;                 /* global variable      */
int square(int n);          /* function prototype   */

/* 5. main() FUNCTION - execution starts here */
int main()
{
    /* 5a. declaration part */
    int r = 5, result;

    /* 5b. executable part */
    area = PI * r * r;
    result = square(r);

    printf("Area of circle = %.2f${NL}", area);
    printf("Square of %d = %d${NL}", r, result);

    return 0;      /* 0 means success */
}

/* 6. SUB PROGRAM SECTION - user-defined functions */
int square(int n)
{
    return (n * n);
}`}
          />
        </SubSection>

        <DefList
          items={[
            {
              term: "1. Documentation Section",
              def: (
                <>
                  A set of <strong>comments</strong> describing the program name,
                  author, date and purpose, written between{" "}
                  <IC>/* ... */</IC>. Completely ignored by the compiler - it is
                  meant only for human readers.
                </>
              ),
            },
            {
              term: "2. Link Section",
              def: (
                <>
                  Instructs the preprocessor to include header files that give
                  access to library functions. You cannot use <IC>printf()</IC>{" "}
                  without <IC>#include &lt;stdio.h&gt;</IC>. These directives
                  take <strong>no semicolon</strong>.
                </>
              ),
            },
            {
              term: "3. Definition Section",
              def: (
                <>
                  Defines symbolic constants using <IC>#define</IC>. They are
                  replaced by the preprocessor <em>before</em> compilation, so
                  they use no memory and can never be changed at run time.
                </>
              ),
            },
            {
              term: "4. Global Declaration",
              def: (
                <>
                  Variables and function prototypes declared outside every
                  function. A global variable can be used by{" "}
                  <strong>every</strong> function in the file from that point on.
                </>
              ),
            },
            {
              term: "5. main() Function",
              def: (
                <>
                  The <strong>compulsory</strong> section and the entry point of
                  every C program. It is split into a <em>declaration part</em>{" "}
                  (all variables declared first, the old C89 rule) and an{" "}
                  <em>executable part</em> (the actual statements).
                </>
              ),
            },
            {
              term: "6. Sub Program Section",
              def: (
                <>
                  All user-defined functions, also called subroutines or modules.
                  They are prototyped in section 4, defined here and{" "}
                  <em>called</em> from main(). This is what makes C modular.
                </>
              ),
            },
          ]}
        />

        <NoteBox type="tip" title="The Two Golden Rules of main()">
          1. Every C program must have <strong>exactly one</strong>{" "}
          <IC>main()</IC> - more than one, or none at all, is a compile error.{" "}
          <br />
          2. Execution <strong>always begins</strong> at the first statement of{" "}
          <IC>main()</IC> and ends when <IC>main()</IC> returns, no matter how
          many other functions exist.
        </NoteBox>
      </Section>

      {/* ================= 1.6 FIRST PROGRAM ================= */}
      <Section title="1.6 Your First Program - Line by Line">
        <CodeBlock
          title="hello.c"
          output="Hello, World!"
          code={`#include <stdio.h>

int main()
{
    printf("Hello, World!${NL}");
    return 0;
}`}
        />
        <p className="mb-2 text-[14px] text-slate-300">
          Only six lines, but each one does something essential.{" "}
          <strong className="text-white">Tap any line below:</strong>
        </p>
        <LineAnatomy />

        <SubSection title="Two more beginner programs">
          <CodeBlock
            title="sum.c"
            output={`Enter two numbers: 12 8
Sum = 20`}
            code={`#include <stdio.h>

int main()
{
    int a, b, sum;              /* declaration part */

    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);     /* & means address of */

    sum = a + b;                /* executable part */
    printf("Sum = %d${NL}", sum);

    return 0;
}`}
          />
          <CodeBlock
            title="area.c"
            code={`#include <stdio.h>
#define PI 3.14159          /* definition section */

int main()
{
    float radius = 5.0f;
    float area, circ;

    area = PI * radius * radius;
    circ = 2 * PI * radius;

    printf("Radius        = %.0f${NL}", radius);
    printf("Area          = %f${NL}", area);
    printf("Circumference = %f${NL}", circ);

    return 0;
}`}
            output={`Radius        = 5
Area          = 78.539749
Circumference = 31.415899`}
          />
        </SubSection>
      </Section>

      {/* ================= 1.7 CONVENTIONS ================= */}
      <Section title="1.7 C Programming Conventions">
        <p className="mb-4 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          <strong className="text-white">Conventions</strong> are not compiler
          rules - a messy program still compiles. They are professional habits
          that make code <em>readable, consistent and maintainable</em>, and in
          exams neat formatting earns marks.
        </p>

        <SubSection title="A. Naming Conventions">
          <Table
            headers={["Entity", "Convention", "Example"]}
            rows={[
              ["Variable", "lowercase or camelCase, meaningful", <span key="v" className="font-mono text-[11.5px] text-emerald-300">studentAge, totalMarks</span>],
              ["Function", "lowercase, verb based", <span key="f" className="font-mono text-[11.5px] text-emerald-300">calculateArea(), printList()</span>],
              ["Symbolic constant", "ALL UPPER_CASE with underscores", <span key="c" className="font-mono text-[11.5px] text-emerald-300">MAX_SIZE, PI, TAX_RATE</span>],
              ["Loop counter", "single letters i, j, k", <span key="l" className="font-mono text-[11.5px] text-emerald-300">for (i = 0; ...)</span>],
              ["Pointer", "p prefix or Ptr suffix", <span key="p" className="font-mono text-[11.5px] text-emerald-300">pName, countPtr</span>],
              ["Header file", "lowercase name with .h", <span key="h" className="font-mono text-[11.5px] text-emerald-300">stdio.h, myutils.h</span>],
            ]}
          />
        </SubSection>

        <SubSection title="B. Formatting Conventions">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4">
              <h4 className="mb-2.5 text-sm font-bold text-emerald-300">
                ✅ Always Do This
              </h4>
              <ul className="space-y-2 text-[13px] text-slate-300">
                <li>• Indent the body of every <IC>{"{ }"}</IC> block by 4 spaces</li>
                <li>• Write one statement per line</li>
                <li>• Put spaces around operators: <IC>a = b + c</IC></li>
                <li>• Add a blank line between logical sections</li>
                <li>• Comment above every function using <IC>/* */</IC></li>
                <li>• Keep lines under about 80 characters</li>
                <li>• Align opening and closing braces consistently</li>
              </ul>
            </div>
            <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-4">
              <h4 className="mb-2.5 text-sm font-bold text-red-300">
                ❌ Never Do This
              </h4>
              <ul className="space-y-2 text-[13px] text-slate-300">
                <li>• Do not use a keyword as a name (<del>int float;</del>)</li>
                <li>• Do not start a name with a digit (<del>2total</del>)</li>
                <li>• No spaces or symbols in names (<del>roll no</del>, <del>my-id</del>)</li>
                <li>• No meaningless names (<del>aaa</del>, <del>x1x2</del>)</li>
                <li>• Do not mix styles (<del>RollNo</del> and <del>rollno</del>)</li>
                <li>• No semicolon after <IC>#include</IC> or <IC>#define</IC></li>
                <li>• Do not squeeze everything onto one line</li>
              </ul>
            </div>
          </div>
        </SubSection>

        <SubSection title="C. See the Difference">
          <div className="grid gap-3 lg:grid-cols-2">
            <div>
              <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-red-400">
                ✗ Bad style - compiles, but unreadable
              </div>
              <CodeBlock
                code={`int main(){int a=5,b=10,c;c=a+b;printf("%d",c);return 0;}`}
              />
            </div>
            <div>
              <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                ✓ Good style - the same program, professionally written
              </div>
              <CodeBlock
                code={`/* Program : add.c  -  adds two numbers */
#include <stdio.h>

int main()
{
    int first  = 5;
    int second = 10;
    int sum;

    sum = first + second;

    printf("Sum = %d${NL}", sum);

    return 0;
}`}
              />
            </div>
          </div>
        </SubSection>

        <NoteBox type="exam" title="Why conventions matter (2-mark answer)">
          Conventions improve <strong>readability</strong>, make debugging
          easier, let <strong>team members</strong> understand each other's code,
          reduce careless mistakes and give software a consistent professional
          look - all without changing how the program runs.
        </NoteBox>
      </Section>

      {/* ================= 1.8 CHARACTER SET ================= */}
      <Section title="1.8 The C Character Set">
        <p className="mb-4 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          The <strong className="text-white">character set</strong> is the set of
          all letters, digits and symbols the C compiler can recognise. Anything
          typed outside this set (except inside a comment or a string) produces
          an error. C uses the <strong className="text-white">ASCII</strong>{" "}
          coding scheme, so every character has a numeric code from 0 to 255.
        </p>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              g: "A",
              t: "Alphabets",
              n: "52 chars",
              c: "from-emerald-400 to-emerald-600",
              list: "A B C ... X Y Z\na b c ... x y z",
              note: "C is case sensitive: A (65) and a (97) are different characters.",
            },
            {
              g: "0",
              t: "Digits",
              n: "10 chars",
              c: "from-cyan-400 to-cyan-600",
              list: "0 1 2 3 4 5 6 7 8 9",
              note: "Used to build numeric constants of any size.",
            },
            {
              g: "#",
              t: "Special Symbols",
              n: "29 chars",
              c: "from-violet-400 to-violet-600",
              list: specialChars.slice(0, 16).join(" ") + "\n" + specialChars.slice(16).join(" "),
              note: "Most of them work as operators or punctuation.",
            },
            {
              g: "␣",
              t: "White Spaces",
              n: "4 types",
              c: "from-amber-400 to-orange-600",
              list: "blank space, tab,\nnewline, form feed",
              note: "They separate tokens and are ignored outside strings.",
            },
          ].map((k) => (
            <div
              key={k.t}
              className="min-w-0 rounded-xl border border-slate-700 bg-slate-800/50 p-3.5"
            >
              <div className="mb-2 flex items-center justify-between">
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br ${k.c} font-mono text-base font-bold text-white`}
                >
                  {k.g}
                </div>
                <span className="rounded-full bg-slate-900 px-2 py-0.5 text-[10px] font-bold text-slate-400">
                  {k.n}
                </span>
              </div>
              <div className="mb-1.5 text-sm font-bold text-white">{k.t}</div>
              <pre className="mb-2 overflow-x-auto whitespace-pre font-mono text-[11.5px] leading-relaxed text-emerald-300">
                {k.list}
              </pre>
              <p className="text-[12px] leading-snug text-slate-500">{k.note}</p>
            </div>
          ))}
        </div>

        <NoteBox type="info" title="Total = 52 + 10 + 29 = 95 printable characters">
          Together with the white-space characters, these form the complete C
          character set, based on ASCII - the American Standard Code for
          Information Interchange.
        </NoteBox>

        <SubSection title="Sample ASCII codes worth remembering">
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6">
            {[
              ["A", "65"],
              ["Z", "90"],
              ["a", "97"],
              ["z", "122"],
              ["0", "48"],
              ["9", "57"],
              ["space", "32"],
              [NL, "10"],
              [NUL, "0"],
              ["+", "43"],
              ["=", "61"],
              ["?", "63"],
            ].map(([c, v]) => (
              <div
                key={c}
                className="rounded-lg border border-slate-700 bg-slate-900/60 px-2 py-2 text-center"
              >
                <div className="font-mono text-[12.5px] text-amber-300">
                  {DQ}{c}{DQ}
                </div>
                <div className="font-mono text-[11px] text-slate-500">{v}</div>
              </div>
            ))}
          </div>
          <p className="mt-3 text-[13px] leading-relaxed text-slate-400">
            Useful tricks: convert a digit character to its integer value with{" "}
            <IC>ch - {DQ}0{DQ}</IC>, and convert an uppercase letter to lowercase
            with <IC>ch + 32</IC>, because <IC>{DQ}a{DQ} - {DQ}A{DQ} == 32</IC>.
          </p>
        </SubSection>

        <SubSection title="Escape Sequences (non-printable characters)">
          <Table
            headers={["Sequence", "Name", "ASCII", "What it does"]}
            rows={[
              [<IC key="1">{NL}</IC>, "Newline / line feed", "10", "Moves the cursor to the next line"],
              [<IC key="2">{TAB}</IC>, "Horizontal tab", "9", "Inserts a tab space"],
              [<IC key="3">{BS}r</IC>, "Carriage return", "13", "Returns to the start of the line"],
              [<IC key="4">{BS}b</IC>, "Backspace", "8", "Deletes the previous character"],
              [<IC key="5">{NUL}</IC>, "Null character", "0", "Marks the end of a string"],
              [<IC key="6">{BS}{BS}</IC>, "Backslash", "92", "Prints one backslash"],
              [<IC key="7">{BS}{SQ}</IC>, "Single quote", "39", "Prints an apostrophe"],
              [<IC key="8">{BS}{DQ}</IC>, "Double quote", "34", "Prints quotation marks"],
              [<IC key="9">{BS}a</IC>, "Alert / bell", "7", "Beeps the speaker"],
              [<IC key="10">{BS}v</IC>, "Vertical tab", "11", "Moves down one tab line"],
            ]}
          />
        </SubSection>
      </Section>

      {/* ================= 1.9 TOKENS ================= */}
      <Section title="1.9 Tokens - the Smallest Units of C">
        <p className="mb-4 text-[14.5px] leading-relaxed text-slate-300 sm:text-base">
          A <strong className="text-white">token</strong> is the smallest
          individual unit of a C program that the compiler recognises. The
          compiler's very first job, called lexical analysis, is to break your
          source code into a stream of tokens. C has{" "}
          <strong className="text-white">six</strong> kinds:
        </p>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { t: "1. Keywords", c: "text-violet-300", d: "32 reserved words with a fixed meaning", e: "int, float, if, else, for, while, return" },
            { t: "2. Identifiers", c: "text-emerald-300", d: "Names invented by the programmer", e: "sum, roll_no, calculateArea" },
            { t: "3. Constants", c: "text-cyan-300", d: "Fixed values that never change", e: `100, 3.14, 'A', "Hello"` },
            { t: "4. Strings", c: "text-amber-300", d: "A sequence of characters in quotes", e: `"C Programming"` },
            { t: "5. Operators", c: "text-pink-300", d: "Symbols that perform operations", e: "+ - * / % = == < &&" },
            { t: "6. Special Symbols", c: "text-sky-300", d: "Punctuation and grouping symbols", e: "# [ ] { } ( ) , ; ->" },
          ].map((k) => (
            <div
              key={k.t}
              className="min-w-0 rounded-xl border border-slate-700 bg-slate-900/50 p-3.5"
            >
              <div className={`mb-1 text-sm font-bold ${k.c}`}>{k.t}</div>
              <div className="mb-2 text-[12.5px] text-slate-400">{k.d}</div>
              <div className="break-words rounded-lg bg-slate-950/70 px-2.5 py-1.5 font-mono text-[11.5px] text-emerald-300">
                {k.e}
              </div>
            </div>
          ))}
        </div>

        <SubSection title="Example - counting the tokens in one line">
          <CodeBlock code={`total = price + quantity * 0.18;`} />
          <div className="flex flex-wrap gap-2">
            {[
              ["total", "identifier"],
              ["=", "operator"],
              ["price", "identifier"],
              ["+", "operator"],
              ["quantity", "identifier"],
              ["*", "operator"],
              ["0.18", "constant"],
              [";", "special symbol"],
            ].map(([tok, kind]) => (
              <div
                key={tok}
                className="rounded-lg border border-slate-700 bg-slate-900/60 px-2.5 py-1.5"
              >
                <span className="font-mono text-[12.5px] text-white">{tok}</span>
                <span className="ml-1.5 text-[10.5px] text-slate-500">{kind}</span>
              </div>
            ))}
          </div>
          <p className="mt-3 text-[13px] text-slate-400">
            Eight tokens in total. The spaces between them are plain{" "}
            <strong className="text-white">white space</strong> and are thrown
            away by the compiler.
          </p>
        </SubSection>

        <NoteBox type="tip" title="Coming up in Chapter 2">
          Keywords, identifiers, data types, modifiers, variables and constants
          are each explained in full detail, with all 32 keywords, size tables
          and valid/invalid examples, in the next chapter.
        </NoteBox>
      </Section>

      {/* ================= 1.10 ERRORS ================= */}
      <Section title="1.10 Types of Errors in C">
        <Table
          headers={["Error", "When detected", "Example", "Does it run?"]}
          rows={[
            [<strong key="s" className="text-white">Syntax error</strong>, "At compile time", <span key="s2" className="font-mono text-[11px]">printf("Hi") with no ;</span>, "No - will not compile"],
            [<strong key="m" className="text-white">Semantic error</strong>, "At compile time", <span key="m2" className="font-mono text-[11px]">int a = "hello";</span>, "No - the meaning is wrong"],
            [<strong key="r" className="text-white">Runtime error</strong>, "While executing", <span key="r2" className="font-mono text-[11px]">c = a / 0; crashes</span>, "Starts, then crashes"],
            [<strong key="l" className="text-white">Logical error</strong>, "Never - output is wrong", <span key="l2" className="font-mono text-[11px]">avg = a + b / 2;</span>, "Yes - but the answer is wrong"],
            [<strong key="k" className="text-white">Linker error</strong>, "At link time", "Calling a function that was never defined", "No - no executable is produced"],
          ]}
        />

        <SubSection title="The 10 most common beginner mistakes">
          <ol className="ml-5 list-decimal space-y-2 text-[13.5px] text-slate-300 sm:text-sm">
            <li>Forgetting the semicolon <IC>;</IC> at the end of a statement</li>
            <li>Using <IC>=</IC> instead of <IC>==</IC> inside an <IC>if</IC></li>
            <li>Missing the <IC>&amp;</IC> in scanf, as in <IC>scanf({DQ}%d{DQ}, a)</IC></li>
            <li>Unbalanced braces <IC>{"{ }"}</IC> or parentheses</li>
            <li>Writing a capital <IC>Printf()</IC> - C is case sensitive</li>
            <li>Forgetting <IC>#include &lt;stdio.h&gt;</IC> before using printf</li>
            <li>Putting a semicolon after <IC>#include</IC> or <IC>#define</IC></li>
            <li>Integer division: <IC>5 / 2</IC> gives <IC>2</IC>, not <IC>2.5</IC></li>
            <li>Using a variable before declaring it</li>
            <li>Comparing two strings with <IC>==</IC> instead of <IC>strcmp()</IC></li>
          </ol>
        </SubSection>
      </Section>

      {/* ================= SUMMARY ================= */}
      <div className="mt-8 rounded-2xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-4 sm:p-6">
        <h3 className="mb-3 flex items-center gap-2 text-lg font-bold text-white sm:text-xl">
          <span>📝</span> Chapter 1 - Complete Revision Notes
        </h3>
        <div className="space-y-3 text-[13.5px] leading-relaxed text-slate-300 sm:text-sm">
          {[
            ["History: ", <>ALGOL (1960) → CPL → BCPL (1967) → B (1970) → <strong className="text-white">C (1972, Dennis Ritchie, Bell Labs)</strong> → K&amp;R book (1978) → ANSI C / C89 (1989) → C99 → C11 → C17. Built to rewrite UNIX on the PDP-11.</>],
            ["Features: ", "Simple, fast, portable, structured, middle-level, rich library, pointer and memory control, rich operators, extensible, and the foundation for C++, Java and Python."],
            ["Build process: ", <>Source <IC>.c</IC> → Preprocessor <IC>.i</IC> → Compiler <IC>.s</IC> → Assembler <IC>.o</IC> → Linker <IC>.exe</IC> → Loader → execution starting at <IC>main()</IC>.</>],
            ["Structure (6 sections): ", <>Documentation → Link (<IC>#include</IC>) → Definition (<IC>#define</IC>) → Global declaration → <IC>main()</IC> with a declaration part and an executable part → Sub programs.</>],
            ["Conventions: ", "lowercase camelCase variables, UPPER_CASE constants, verb based function names, 4-space indentation, meaningful names, comments and one statement per line."],
            ["Character set: ", <>52 alphabets + 10 digits + 29 special symbols plus white space = 95 printable ASCII characters. Escape sequences such as <IC>{NL}</IC>, <IC>{TAB}</IC> and <IC>{NUL}</IC> stand for non-printable characters.</>],
            ["Tokens (6 kinds): ", "Keywords, identifiers, constants, strings, operators and special symbols."],
          ].map(([label, body], i) => (
            <div key={i} className="rounded-lg bg-slate-950/50 p-3">
              <span className="font-bold text-emerald-300">{label}</span>
              {body}
            </div>
          ))}
        </div>
      </div>

      {/* ================= EXAM Q&A ================= */}
      <div className="mt-6 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-4 sm:p-5">
        <h3 className="mb-3 flex items-center gap-2 text-base font-bold text-emerald-300 sm:text-lg">
          <span>🎓</span> Important Exam Questions (tap to reveal answers)
        </h3>
        <Collapse question="1. Who developed the C language, when and where, and why was it created?">
          C was developed by <strong>Dennis M. Ritchie</strong> in{" "}
          <strong>1972</strong> at <strong>Bell Telephone Laboratories</strong>,
          Murray Hill, New Jersey, USA. He created it to rewrite the{" "}
          <strong>UNIX operating system</strong> in a high-level language so the
          OS could be ported to different computers instead of being rewritten in
          assembly every time.
        </Collapse>
        <Collapse question="2. Explain the evolution of C from ALGOL to ANSI C.">
          ALGOL (1960, international committee) was structured but too abstract →
          CPL (1963, Cambridge and London) → BCPL (1967, Martin Richards) was
          small and typeless → B (1970, Ken Thompson) adapted BCPL for UNIX on
          the PDP-7 → <strong>C (1972, Ritchie)</strong> added data types,
          arrays, structures and pointers. Kernighan and Ritchie documented it in
          1978, and ANSI standardised it as C89 in 1989 (ISO C90), followed by
          C99, C11 and C17.
        </Collapse>
        <Collapse question="3. Draw and explain the structure of a C program.">
          A C program has six sections: (1) <strong>Documentation</strong> -
          comments; (2) <strong>Link</strong> - <code>#include</code> header
          files; (3) <strong>Definition</strong> - <code>#define</code>{" "}
          constants; (4) <strong>Global declaration</strong> - global variables
          and function prototypes; (5) <strong>main()</strong> - the compulsory
          entry point containing a declaration part followed by an executable
          part; (6) <strong>Sub programs</strong> - user-defined functions.
          Execution always begins at the first statement of main().
        </Collapse>
        <Collapse question="4. Explain the various stages in the execution of a C program.">
          (i) <strong>Editing</strong> - writing the source in a .c file; (ii){" "}
          <strong>Preprocessing</strong> - expanding #include and #define to
          produce a .i file; (iii) <strong>Compilation</strong> - converting to
          assembly (.s) and reporting syntax errors; (iv) <strong>Assembly</strong>{" "}
          - producing object code (.o); (v) <strong>Linking</strong> - joining our
          object code with library code to build the executable; (vi){" "}
          <strong>Loading</strong> - the loader places the program in memory and
          execution starts at main().
        </Collapse>
        <Collapse question="5. Why is C called a middle-level language?">
          Because it combines the features of high-level languages - English-like
          syntax, functions, structures and portability - with the features of
          low-level languages - bitwise operators, pointer arithmetic, direct
          memory access and the ability to write system software such as OS
          kernels and device drivers. It is therefore neither purely high-level
          nor purely low-level.
        </Collapse>
        <Collapse question="6. List the character set of C with the count of each group.">
          (a) <strong>Alphabets</strong> - 52 characters (A-Z and a-z); (b){" "}
          <strong>Digits</strong> - 10 characters (0-9); (c){" "}
          <strong>Special symbols</strong> - 29 characters; plus{" "}
          <strong>white-space characters</strong> such as space, tab, newline and
          carriage return. The total of printable characters is 95, all based on
          ASCII.
        </Collapse>
        <Collapse question="7. What are the six types of tokens in C? Give two examples of each.">
          (1) <strong>Keywords</strong> - int, while; (2){" "}
          <strong>Identifiers</strong> - marks, total_sum; (3){" "}
          <strong>Constants</strong> - 100 and the character A; (4){" "}
          <strong>Strings</strong> - quoted text; (5) <strong>Operators</strong> -
          plus and logical AND; (6) <strong>Special symbols</strong> - semicolon
          and braces.
        </Collapse>
        <Collapse question="8. Differentiate between a syntax error, a runtime error and a logical error.">
          A <strong>syntax error</strong> breaks the grammar rules of C and is
          caught by the compiler, so the program never compiles, for example a
          missing semicolon. A <strong>runtime error</strong> appears while the
          program is running and usually crashes it, such as dividing by zero. A{" "}
          <strong>logical error</strong> is a mistake in the algorithm - the
          program compiles and runs but produces the wrong output, and only
          testing can reveal it.
        </Collapse>
      </div>

      {/* ================= QUIZ ================= */}
      <div className="mt-6">
        <Quiz
          questions={[
            {
              q: "C was developed by whom, and in which year?",
              options: ["Ken Thompson, 1970", "Dennis Ritchie, 1972", "Brian Kernighan, 1978", "Martin Richards, 1967"],
              answer: 1,
              explain: "Dennis M. Ritchie developed C in 1972 at Bell Labs. Ken Thompson made B in 1970, Kernighan co-authored the 1978 book, and Richards made BCPL in 1967.",
            },
            {
              q: "Which language is the immediate ancestor of C?",
              options: ["ALGOL", "BCPL", "B", "CPL"],
              answer: 2,
              explain: "C was created by improving the B language written by Ken Thompson, which itself came from BCPL.",
            },
            {
              q: "Which section of a C program is compulsory?",
              options: ["Documentation section", "Link section", "main() function", "Global declaration section"],
              answer: 2,
              explain: "Every C program must contain exactly one main() function and execution always starts there. All the other sections are optional.",
            },
            {
              q: "How many sections does a complete C program have?",
              options: ["4", "5", "6", "8"],
              answer: 2,
              explain: "Documentation, Link, Definition, Global Declaration, main() and Sub-programs - six sections in total.",
            },
            {
              q: "Which stage of the build produces the .i file?",
              options: ["Compiler", "Preprocessor", "Assembler", "Linker"],
              answer: 1,
              explain: "The preprocessor expands #include and #define and writes the expanded source into a .i file.",
            },
            {
              q: "The job of the linker is to...",
              options: ["Remove comments from the source", "Translate C into assembly", "Combine object code with library code", "Allocate memory for variables"],
              answer: 2,
              explain: "The linker joins your .o object file with library object files, for example the real code of printf, and produces the final executable.",
            },
            {
              q: "How many alphabetic characters are in the C character set?",
              options: ["26", "46", "52", "62"],
              answer: 2,
              explain: "26 uppercase letters A-Z plus 26 lowercase letters a-z makes 52 alphabetic characters.",
            },
            {
              q: "Which of these is NOT part of the C character set?",
              options: ["Digits 0-9", "Alphabets A-Z", "Special symbols", "Devanagari script letters"],
              answer: 3,
              explain: "The C character set is limited to ASCII - alphabets, digits and special symbols. Other scripts are not recognised by the compiler.",
            },
            {
              q: "Which is the correct convention for a symbolic constant?",
              options: ["maxValue", "MAX_VALUE", "MaxValue", "max value"],
              answer: 1,
              explain: "Symbolic constants are written in ALL UPPER_CASE with underscores, for example MAX_SIZE, PI or TAX_RATE.",
            },
            {
              q: "A program compiles and runs but prints a wrong result. This is a...",
              options: ["Syntax error", "Runtime error", "Logical error", "Linker error"],
              answer: 2,
              explain: "A logical error is a flaw in the algorithm or expression. The compiler cannot detect it - only testing the output can.",
            },
            {
              q: "Which of the following is NOT a token type in C?",
              options: ["Keywords", "Identifiers", "Comments", "Strings"],
              answer: 2,
              explain: "Comments are stripped out by the preprocessor and never become tokens. The six token types are keywords, identifiers, constants, strings, operators and special symbols.",
            },
            {
              q: `Which escape sequence marks the end of a string?`,
              options: [NL, NUL, TAB, "\\b"],
              answer: 1,
              explain: "The null character, ASCII 0, is automatically appended to every string literal in C to mark its end.",
            },
          ]}
        />
      </div>

      {/* Practice task */}
      <div className="mt-6 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 sm:p-5">
        <h3 className="mb-2 flex items-center gap-2 text-base font-bold text-amber-300">
          <span>🏋️</span> Practice Task
        </h3>
        <p className="mb-3 text-[13.5px] leading-relaxed text-slate-300 sm:text-sm">
          Write a program <IC>profile.c</IC> containing all six sections, which
          prints your <strong>name, roll number, branch and city</strong> on
          separate lines using a single <IC>printf()</IC> with escape sequences,
          and uses one <IC>#define</IC> constant for your roll number.
        </p>
        <details className="rounded-xl border border-slate-700 bg-slate-900/60">
          <summary className="cursor-pointer p-3 text-[13px] font-semibold text-amber-300">
            👀 Show model answer
          </summary>
          <div className="border-t border-slate-800">
            <CodeBlock
              title="profile.c"
              output={`Name   : Aarav Sharma
Roll   : 23CS1042
Branch : Computer Science
City   : Jaipur`}
              code={`/* profile.c  -  Author : Aarav Sharma */
#include <stdio.h>

#define ROLL "23CS1042"      /* definition section */

int main()
{
    char name[]   = "Aarav Sharma";
    char branch[] = "Computer Science";
    char city[]   = "Jaipur";

    printf("Name   : %s${NL}Roll   : %s${NL}", name, ROLL);
    printf("Branch : %s${NL}City   : %s${NL}", branch, city);

    return 0;
}`}
            />
          </div>
        </details>
      </div>
    </div>
  );
}
