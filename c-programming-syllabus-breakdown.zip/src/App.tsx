import { useEffect, useState } from "react";
import Chapter1 from "./chapters/Chapter1";
import Chapter2 from "./chapters/Chapter2";
import Chapter3 from "./chapters/Chapter3";
import Chapter4 from "./chapters/Chapter4";
import Chapter5 from "./chapters/Chapter5";
import Chapter6 from "./chapters/Chapter6";

interface ChapterInfo {
  id: number;
  title: string;
  short: string;
  subtitle: string;
  icon: string;
  color: string;
  depth: "deep" | "core";
}

const chapters: ChapterInfo[] = [
  {
    id: 1,
    title: "Introduction to C Programming",
    short: "Introduction to C",
    subtitle: "History, Structure, Conventions, Character Set",
    icon: "📖",
    color: "from-emerald-500 to-cyan-500",
    depth: "deep",
  },
  {
    id: 2,
    title: "Identifiers, Data Types & Variables",
    short: "Data Types & Variables",
    subtitle: "Keywords, Modifiers, Constants",
    icon: "🔤",
    color: "from-cyan-500 to-sky-500",
    depth: "core",
  },
  {
    id: 3,
    title: "Operators & Precedence",
    short: "Operators",
    subtitle: "All operators and their rules",
    icon: "➗",
    color: "from-sky-500 to-violet-500",
    depth: "core",
  },
  {
    id: 4,
    title: "Input & Output Operations",
    short: "Input & Output",
    subtitle: "printf, scanf, getchar, putchar",
    icon: "⌨️",
    color: "from-fuchsia-500 to-pink-500",
    depth: "core",
  },
  {
    id: 5,
    title: "Conditional Statements & Switch",
    short: "Conditionals",
    subtitle: "if, else, nested if, switch",
    icon: "🔀",
    color: "from-rose-500 to-pink-500",
    depth: "core",
  },
  {
    id: 6,
    title: "Looping Statements",
    short: "Loops",
    subtitle: "for, while, break, continue, nested for",
    icon: "🔁",
    color: "from-amber-500 to-orange-500",
    depth: "core",
  },
];

function renderChapter(id: number) {
  switch (id) {
    case 1:
      return <Chapter1 />;
    case 2:
      return <Chapter2 />;
    case 3:
      return <Chapter3 />;
    case 4:
      return <Chapter4 />;
    case 5:
      return <Chapter5 />;
    case 6:
      return <Chapter6 />;
    default:
      return <Chapter1 />;
  }
}

export default function App() {
  const [active, setActive] = useState(1);
  const [drawer, setDrawer] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    setDrawer(false);
  }, [active]);

  useEffect(() => {
    document.body.style.overflow = drawer ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [drawer]);

  const current = chapters.find((c) => c.id === active)!;
  const pct = Math.round((active / chapters.length) * 100);

  const Nav = (
    <div className="min-w-0">
      <p className="mb-3 px-1 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">
        Unit 1 · Chapters
      </p>
      <nav className="space-y-1.5">
        {chapters.map((ch) => {
          const on = ch.id === active;
          return (
            <button
              key={ch.id}
              onClick={() => setActive(ch.id)}
              className={`flex w-full items-start gap-2.5 rounded-xl border p-2.5 text-left transition ${
                on
                  ? "border-slate-600 bg-slate-800/80"
                  : "border-transparent hover:border-slate-800 hover:bg-slate-900/60"
              }`}
            >
              <span
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br text-base shadow-lg ${ch.color} ${
                  on ? "opacity-100" : "opacity-70"
                }`}
              >
                {ch.icon}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-1.5">
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider ${
                      on ? "text-emerald-300" : "text-slate-500"
                    }`}
                  >
                    Ch {ch.id}
                  </span>
                  {ch.depth === "deep" && (
                    <span className="rounded bg-violet-500/20 px-1.5 py-px text-[9px] font-bold uppercase text-violet-300">
                      In-Depth
                    </span>
                  )}
                </span>
                <span
                  className={`block text-[13px] font-semibold leading-snug ${
                    on ? "text-white" : "text-slate-300"
                  }`}
                >
                  {ch.short}
                </span>
                <span className="block truncate text-[11px] text-slate-500">
                  {ch.subtitle}
                </span>
              </span>
            </button>
          );
        })}
      </nav>

      <div className="mt-4 rounded-xl border border-slate-800 bg-slate-900/50 p-3.5">
        <div className="mb-2 flex items-center justify-between text-[11px]">
          <span className="font-semibold text-slate-300">Your progress</span>
          <span className="font-bold text-emerald-300">
            {active} / {chapters.length}
          </span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-cyan-400 transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen overflow-x-hidden bg-slate-950 text-slate-100 antialiased">
      {/* soft background glow */}
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-32 -right-32 h-72 w-72 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="absolute top-1/2 -left-32 h-72 w-72 rounded-full bg-violet-500/10 blur-3xl" />
      </div>

      {/* ---------------- HEADER ---------------- */}
      <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1400px] items-center gap-2 px-3 py-2.5 sm:px-5 sm:py-3">
          <button
            onClick={() => setDrawer(true)}
            aria-label="Open chapter list"
            className="rounded-lg border border-slate-700 bg-slate-900 p-2 text-slate-300 transition active:scale-95 lg:hidden"
          >
            <svg
              className="h-5 w-5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path d="M4 6h16M4 12h16M4 18h16" strokeLinecap="round" />
            </svg>
          </button>

          <div className="flex min-w-0 flex-1 items-center gap-2.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 via-cyan-500 to-violet-600 text-base font-bold text-white shadow-lg shadow-emerald-500/20">
              C
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[13.5px] font-bold leading-tight text-white sm:text-base">
                C Programming · Unit 1
              </span>
              <span className="hidden truncate text-[11px] text-slate-400 sm:block">
                Fundamentals &amp; Control Structures
              </span>
            </span>
          </div>

          <span className="shrink-0 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10.5px] font-bold text-emerald-300 sm:px-3 sm:text-xs">
            {active}/{chapters.length}
          </span>
        </div>
      </header>

      {/* ---------------- MOBILE DRAWER ---------------- */}
      <div
        className={`fixed inset-0 z-40 lg:hidden ${drawer ? "" : "pointer-events-none"}`}
      >
        <div
          onClick={() => setDrawer(false)}
          className={`absolute inset-0 bg-black/70 transition-opacity duration-300 ${
            drawer ? "opacity-100" : "opacity-0"
          }`}
        />
        <aside
          className={`absolute inset-y-0 left-0 w-[86%] max-w-xs overflow-y-auto border-r border-slate-800 bg-slate-950 px-3 pb-8 pt-4 transition-transform duration-300 ${
            drawer ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="mb-4 flex items-center justify-between">
            <span className="text-sm font-bold text-white">Chapters</span>
            <button
              onClick={() => setDrawer(false)}
              aria-label="Close"
              className="rounded-lg border border-slate-700 bg-slate-900 p-1.5 text-slate-400"
            >
              <svg
                className="h-4 w-4"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
              </svg>
            </button>
          </div>
          {Nav}
        </aside>
      </div>

      {/* ---------------- BODY ---------------- */}
      <div className="mx-auto flex max-w-[1400px]">
        {/* desktop sidebar */}
        <aside className="sticky top-[53px] hidden h-[calc(100vh-53px)] w-72 shrink-0 overflow-y-auto border-r border-slate-800/80 bg-slate-950/60 px-4 py-6 lg:block">
          {Nav}
        </aside>

        {/* content */}
        <main className="min-w-0 flex-1 overflow-x-hidden px-3 py-6 sm:px-6 sm:py-8 lg:px-10">
          <div className="mx-auto w-full max-w-3xl">
            {/* mobile chapter pill */}
            <div className="mb-4 flex items-center gap-2 lg:hidden">
              <span
                className={`flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br text-sm ${current.color}`}
              >
                {current.icon}
              </span>
              <span className="min-w-0 truncate text-[12px] font-semibold text-slate-400">
                {current.title}
              </span>
            </div>

            {renderChapter(active)}

            {/* pager */}
            <div className="mt-10 flex items-center justify-between gap-3 border-t border-slate-800 pt-6">
              <button
                onClick={() => setActive((a) => Math.max(1, a - 1))}
                disabled={active === 1}
                className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-900/60 px-3 py-2.5 text-[13px] font-semibold text-slate-300 transition active:scale-95 disabled:opacity-30 sm:px-4"
              >
                <svg
                  className="h-4 w-4"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path d="M15 18l-6-6 6-6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Prev
              </button>

              <span className="hidden text-center text-[11px] text-slate-500 sm:block">
                Chapter {active} of {chapters.length} · {current.short}
              </span>

              <button
                onClick={() =>
                  setActive((a) => Math.min(chapters.length, a + 1))
                }
                disabled={active === chapters.length}
                className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-3 py-2.5 text-[13px] font-bold text-white shadow-lg shadow-emerald-500/20 transition active:scale-95 disabled:opacity-30 sm:px-4"
              >
                Next
                <svg
                  className="h-4 w-4"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path d="M9 18l6-6-6-6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>

            {/* quick chapter chips */}
            <div className="mt-6 flex flex-wrap justify-center gap-1.5">
              {chapters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActive(c.id)}
                  className={`h-8 w-8 rounded-lg border text-[12px] font-bold transition ${
                    c.id === active
                      ? "border-emerald-400 bg-emerald-500/20 text-emerald-300"
                      : "border-slate-700 bg-slate-900 text-slate-500 hover:text-slate-300"
                  }`}
                >
                  {c.id}
                </button>
              ))}
            </div>

            <p className="mt-6 text-center text-[11px] text-slate-600">
              C Programming · Unit 1 — Fundamentals &amp; Control Structures
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}
